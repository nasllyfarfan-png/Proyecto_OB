const db = require('../config/config');

/**
 * product.js
 * -----------------------------------------------
 * Modelo de datos para la tabla 'products'.
 */

const Product = {

    // =================================
    // LISTAR TODOS LOS PRODUCTOS
    // =================================
    getAll: (callback) => {

        const sql = `
            SELECT 
                id,
                name,
                description,
                price,
                category,
                stock,
                sku,
                created_at,
                updated_at
            FROM products
            ORDER BY id DESC
        `;

        db.query(sql, (err, results) => {

            if (err) {
                return callback(err, null);
            }

            callback(null, results);
        });
    },


    // =================================
    // BUSCAR PRODUCTO POR ID
    // =================================
    getById: (id, callback) => {

        const sql = `
            SELECT 
                id,
                name,
                description,
                price,
                category,
                stock,
                sku,
                created_at,
                updated_at
            FROM products
            WHERE id = ?
            LIMIT 1
        `;

        db.query(sql, [id], (err, results) => {

            if (err) {
                return callback(err, null);
            }

            if (results.length === 0) {
                return callback(null, null);
            }

            callback(null, results[0]);
        });
    },


    // =================================
    // CREAR PRODUCTO
    // =================================
    create: (product, callback) => {

    const sql = `
        INSERT INTO products
        (
            name,
            description,
            price,
            category,
            stock,
            sku
        )
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    const values = [
        product.name,
        product.description,
        product.price,
        product.category,
        product.stock,
        product.sku
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            return callback(err, null);
        }

        callback(null, {
            id: result.insertId,
            name: product.name,
            description: product.description,
            price: product.price,
            category: product.category,
            stock: product.stock,
            sku: product.sku
        });
    });
},


    // =================================
    // ACTUALIZAR PRODUCTO
    // =================================
    update: (id, product, callback) => {

        const sql = `
            UPDATE products
            SET
                name = ?,
                description = ?,
                price = ?,
                category = ?,
                stock = ?,
                sku = ?,
            WHERE id = ?
        `;

        const values = [
            product.name,
            product.description,
            product.price,
            product.category,
            product.stock,
            product.sku,
            id
        ];

        db.query(sql, values, (err, result) => {

            if (err) {
                return callback(err, null);
            }

            if (result.affectedRows === 0) {
                return callback(null, null);
            }

            callback(null, {
                id: Number(id),
                name: product.name,
                description: product.description,
                price: product.price,
                category: product.category,
                stock: product.stock,
                sku: product.sku,
            });
        });
    },


    // =================================
    // ELIMINAR PRODUCTO
    // =================================
    remove: (id, callback) => {

        const sql = 'DELETE FROM products WHERE id = ?';

        db.query(sql, [id], (err, result) => {

            if (err) {
                return callback(err, null);
            }

            if (result.affectedRows === 0) {
                return callback(null, null);
            }

            callback(null, {
                id: Number(id)
            });
        });
    }

};

module.exports = Product;