const db = require('../config/config');

/**
 * category.js
 * -----------------------------------------------
 * Modelo de datos para la tabla 'categories'.
 * Trabaja con los campos 'name' y 'image_url'.
 */

const Category = {

    // =================================
    // LISTAR TODAS LAS CATEGORÍAS
    // =================================
    getAll: (callback) => {

        const sql = `
            SELECT
                id,
                name,
                image_url
            FROM categories
            ORDER BY id DESC
        `;

        db.query(sql, (err, results) => {

            if (err) {
                return callback(err, null);
            }

            callback(null, results);
        });
    },


    // =================================
    // BUSCAR CATEGORÍA POR ID
    // =================================
    getById: (id, callback) => {

        const sql = `
            SELECT
                id,
                name,
                image_url
            FROM categories
            WHERE id = ?
            LIMIT 1
        `;

        db.query(sql, [id], (err, results) => {

            if (err) {
                return callback(err, null);
            }

            if (results.length === 0) {
                return callback(null, null);
            }

            callback(null, results[0]);
        });
    },


    // =================================
    // CREAR CATEGORÍA
    // =================================
    create: (category, callback) => {

        const sql = `
            INSERT INTO categories
            (
                name,
                image_url
            )
            VALUES (?, ?)
        `;

        const values = [
            category.name,
            category.image_url
        ];

        db.query(sql, values, (err, result) => {

            if (err) {
                return callback(err, null);
            }

            callback(null, {
                id: result.insertId,
                name: category.name,
                image_url: category.image_url
            });
        });
    },


    // =================================
    // ACTUALIZAR CATEGORÍA
    // =================================
    update: (id, category, callback) => {

        const sql = `
            UPDATE categories
            SET
                name = ?,
                image_url = ?
            WHERE id = ?
        `;

        const values = [
            category.name,
            category.image_url,
            id
        ];

        db.query(sql, values, (err, result) => {

            if (err) {
                return callback(err, null);
            }

            if (result.affectedRows === 0) {
                return callback(null, null);
            }

            callback(null, {
                id: Number(id),
                name: category.name,
                image_url: category.image_url
            });
        });
    },


    // =================================
    // ELIMINAR CATEGORÍA
    // =================================
    remove: (id, callback) => {

        const sql = 'DELETE FROM categories WHERE id = ?';

        db.query(sql, [id], (err, result) => {

            if (err) {
                return callback(err, null);
            }

            if (result.affectedRows === 0) {
                return callback(null, null);
            }

            callback(null, {
                id: Number(id)
            });
        });
    }

};

module.exports = Category;