/**
 * productRoutes.js
 * -----------------------------------------------
 * Define las rutas HTTP del CRUD de productos y las conecta
 * con sus funciones correspondientes en productsController.js.
 *
 * Exporta una función que recibe la instancia de Express (app)
 * y registra las rutas sobre ella. Se invoca desde server.js
 * como: productRoutes(app)
 */

const productsController = require('../controllers/productsController');

module.exports = (app) => {

    // GET /api/products -> lista todos los productos
    app.get('/api/products', productsController.getAll);

    // GET /api/products/:id -> obtiene un producto por id
    app.get('/api/products/:id', productsController.getById);

    // POST /api/products -> crea un producto. Body: { name, price }
    app.post('/api/products', productsController.create);

    // PUT /api/products/:id -> actualiza un producto. Body: { name, price }
    app.put('/api/products/:id', productsController.update);

    // DELETE /api/products/:id -> elimina un producto
    app.delete('/api/products/:id', productsController.remove);

};
