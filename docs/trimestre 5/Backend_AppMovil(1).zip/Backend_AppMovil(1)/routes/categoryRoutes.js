/**
 * categoryRoutes.js
 * -----------------------------------------------
 * Define las rutas HTTP del CRUD de categorías.
 */

const categoryController = require('../controllers/categoryController');

module.exports = (app) => {

    // GET /api/category -> lista todas las categorías
    app.get('/api/category', categoryController.getAll);

    // GET /api/category/:id -> obtiene una categoría por id
    app.get('/api/category/:id', categoryController.getById);

    // POST /api/category -> crea una categoría
    app.post('/api/category', categoryController.create);

    // PUT /api/category/:id -> actualiza una categoría
    app.put('/api/category/:id', categoryController.update);

    // DELETE /api/category/:id -> elimina una categoría
    app.delete('/api/category/:id', categoryController.remove);

};