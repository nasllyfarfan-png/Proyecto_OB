const userController = require('../controllers/usersController');

module.exports = (app) => {

    // Crear usuario
    app.post('/api/users/register', userController.register);

    // Compatibilidad con la aplicación móvil
    app.post('/api/user/create', userController.register);

    // Login
    app.post('/api/users/login', userController.login);

};
