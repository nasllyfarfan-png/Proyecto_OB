/**
 * categoryController.js
 * -----------------------------------------------
 * Controlador de categorías: contiene la lógica de negocio
 * para el CRUD (listar, buscar por id, crear, actualizar, eliminar).
 * Es invocado desde routes/categoryRoutes.js.
 *
 * Responde siempre con el formato { success, message, data },
 * igual que productsController.js, para que el frontend pueda
 * reutilizar el mismo tipo ResponseApiDelivery.
 */

const Category = require('../models/category');

module.exports = {

    /**
     * LISTAR CATEGORÍAS
     * GET /api/categories
     */
    getAll(req, res) {

        Category.getAll((err, categories) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al consultar las categorías',
                    error: err
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Categorías obtenidas correctamente',
                data: categories
            });
        });
    },


    /**
     * BUSCAR CATEGORÍA POR ID
     * GET /api/categories/:id
     */
    getById(req, res) {

        const { id } = req.params;

        Category.getById(id, (err, category) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al consultar la categoría',
                    error: err
                });
            }

            if (!category) {
                return res.status(404).json({
                    success: false,
                    message: 'Categoría no encontrada'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Categoría obtenida correctamente',
                data: category
            });
        });
    },


    /**
     * CREAR CATEGORÍA
     * POST /api/categories
     * Body esperado: { name, image_url }
     */
    create(req, res) {

        const { name, image_url } = req.body;

        if (!name || !image_url) {
            return res.status(400).json({
                success: false,
                message: 'Debe indicar un nombre y una URL válidos'
            });
        }

        const category = {
            name,
            image_url
        };

        Category.create(category, (err, data) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al crear la categoría',
                    error: err
                });
            }

            return res.status(201).json({
                success: true,
                message: 'Categoría creada correctamente',
                data: data
            });
        });
    },


    /**
     * ACTUALIZAR CATEGORÍA
     * PUT /api/categories/:id
     * Body esperado: { name, image_url }
     */
    update(req, res) {

        const { id } = req.params;
        const { name, image_url } = req.body;

        if (!name || !image_url) {
            return res.status(400).json({
                success: false,
                message: 'Debe indicar un nombre y una URL válidos'
            });
        }

        const category = {
            name,
            image_url
        };

        Category.update(id, category, (err, data) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al actualizar la categoría',
                    error: err
                });
            }

            if (!data) {
                return res.status(404).json({
                    success: false,
                    message: 'Categoría no encontrada'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Categoría actualizada correctamente',
                data: data
            });
        });
    },


    /**
     * ELIMINAR CATEGORÍA
     * DELETE /api/categories/:id
     */
    remove(req, res) {

        const { id } = req.params;

        Category.remove(id, (err, data) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al eliminar la categoría',
                    error: err
                });
            }

            if (!data) {
                return res.status(404).json({
                    success: false,
                    message: 'Categoría no encontrada'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Categoría eliminada correctamente',
                data: data
            });
        });
    }

};