/**
 * productsController.js
 * -----------------------------------------------
 * Controlador de productos: contiene la lógica de negocio
 * para el CRUD (listar, buscar por id, crear, actualizar, eliminar).
 * Es invocado desde routes/productRoutes.js.
 *
 * Responde siempre con el formato { success, message, data },
 * igual que usersController.js, para que el frontend pueda
 * reutilizar el mismo tipo ResponseApiDelivery.
 */

const Product = require('../models/product');

module.exports = {

    /**
     * LISTAR PRODUCTOS
     * GET /api/products
     */
    getAll(req, res) {
        Product.getAll((err, products) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al consultar los productos',
                    error: err
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Productos obtenidos correctamente',
                data: products
            });
        });
    },

    /**
     * BUSCAR PRODUCTO POR ID
     * GET /api/products/:id
     */
    getById(req, res) {
        const { id } = req.params;

        Product.getById(id, (err, product) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al consultar el producto',
                    error: err
                });
            }

            if (!product) {
                return res.status(404).json({
                    success: false,
                    message: 'Producto no encontrado'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Producto obtenido correctamente',
                data: product
            });
        });
    },

    /**
     * CREAR PRODUCTO
     * POST /api/products
     * Body esperado: { name, description, price, category, stock, sku }
     */
    create(req, res) {
        const { name, description, price, category, stock, sku } = req.body;

        if (!name || price === undefined || price === null || isNaN(Number(price))) {
            return res.status(400).json({
                success: false,
                message: 'Debe indicar un nombre y un precio numérico válidos'
            });
        }

        const product = {
    name,
    description: description ?? '',
    price: Number(price),
    category: category ?? '',
    stock: stock !== undefined && !isNaN(Number(stock))
        ? Number(stock)
        : 0,
    sku: sku ?? ''
};

        Product.create(product, (err, data) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al crear el producto',
                    error: err
                });
            }

            return res.status(201).json({
                success: true,
                message: 'Producto creado correctamente',
                data: data
            });
        });
    },

    /**
     * ACTUALIZAR PRODUCTO
     * PUT /api/products/:id
     * Body esperado: { name, description, price, category, stock, sku }
     */
    update(req, res) {
        const { name, description, price, category, stock, sku } = req.body;

        if (!name || price === undefined || price === null || isNaN(Number(price))) {
            return res.status(400).json({
                success: false,
                message: 'Debe indicar un nombre y un precio numérico válidos'
            });
        }
        const product = {
    name,
    description: description ?? '',
    price: Number(price),
    category: category ?? '',
    stock: stock !== undefined && !isNaN(Number(stock))
        ? Number(stock)
        : 0,
    sku: sku ?? ''
};

        Product.update(id, product, (err, data) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al actualizar el producto',
                    error: err
                });
            }

            if (!data) {
                return res.status(404).json({
                    success: false,
                    message: 'Producto no encontrado'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Producto actualizado correctamente',
                data: data
            });
        });
    },

    /**
     * ELIMINAR PRODUCTO
     * DELETE /api/products/:id
     */
    remove(req, res) {
        const { id } = req.params;

        Product.remove(id, (err, data) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    message: 'Error al eliminar el producto',
                    error: err
                });
            }

            if (!data) {
                return res.status(404).json({
                    success: false,
                    message: 'Producto no encontrado'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Producto eliminado correctamente',
                data: data
            });
        });
    }

};