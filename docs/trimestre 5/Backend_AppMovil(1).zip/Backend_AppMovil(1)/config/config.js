/**
 * config.js
 * -----------------------------------------------
 * Configuración y conexión a la base de datos MySQL.
 */

const mysql = require('mysql2');

// Crea la conexión a la base de datos
const db = mysql.createConnection({
    host: '127.0.0.1',
    port: 3306,
    user: 'root',
    password: '',
    database: 'nodejs_base1'
});

// Abre la conexión
db.connect(function (err) {

    if (err) {
        console.error('Error conectando a MySQL:', err);
        return;
    }

    console.log('Base de datos conectada');
});

module.exports = db;
