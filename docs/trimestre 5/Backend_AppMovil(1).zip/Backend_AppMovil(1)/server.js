const express = require('express');
const passport = require('passport');

/**
 * server.js
 * -----------------------------------------------
 * Punto de entrada del backend. Configura Express, middlewares
 * globales, autenticación con Passport, rutas, y levanta el
 * servidor HTTP en la IP y puerto configurados.
 */

const app = express();
const http = require('http');
const server = http.createServer(app);

const logger = require('morgan');
const cors = require('cors');

// Registro de rutas de usuario (login/register)
const usersRoutes = require('./routes/userRoutes');

// Registro de rutas del CRUD de productos
const productRoutes = require('./routes/productRoutes');

// Registro de rutas del CRUD de categorías
const categoryRoutes = require('./routes/categoryRoutes');

// Puerto configurable vía variable de entorno, con 3000 por defecto
const port = process.env.PORT || 3000;

// Middleware de logging de peticiones HTTP en consola (modo 'dev')
app.use(logger('dev'));

// Parsers para leer el body de las peticiones como JSON
// y como formularios URL-encoded
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Habilita CORS para todas las rutas
app.use(cors());

// Inicializa Passport
app.use(passport.initialize());

// Registra la estrategia JWT definida en config/passport.js
require('./config/passport')(passport);

// Oculta el header 'X-Powered-By: Express' por seguridad
app.disable('x-powered-by');

app.set('port', port);

// Ruta raíz simple
app.get('/', (req, res) => {
    res.send('Ruta raiz del Backend');
});

// Ruta de prueba adicional
app.get('/test', (req, res) => {
    res.send('Estas en la ruta TEST');
});

// Middleware de manejo de errores
app.use((err, req, res, next) => {
    console.log(err);
    res.status(err.status || 500).send(err.stack);
});

// Registra las rutas de usuarios
usersRoutes(app);

// Registra las rutas del CRUD de productos
productRoutes(app);

// Registra las rutas del CRUD de categorías
categoryRoutes(app);

// Levanta el servidor HTTP
server.listen(port, '10.1.202.60', () => {
    console.log(
        'Aplicación de NodeJS ' +
        process.pid +
        ' ejecutándose en ' +
        server.address().address +
        ':' +
        server.address().port
    );
});