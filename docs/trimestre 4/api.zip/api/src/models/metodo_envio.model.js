// Importa las clases Model y DataTypes desde Sequelize.
// Model permite crear el modelo y DataTypes define el tipo de cada columna.
import { Model, DataTypes } from "sequelize";

// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";


// Crea la clase metodoEnvio heredando de Model.
class metodoEnvio extends Model {}


// Inicializa el modelo y define la estructura de la tabla.
metodoEnvio.init({

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único del método de envío.
    id_metodos_envio: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    // ==========================
    // INFORMACIÓN DEL MÉTODO
    // ==========================

    // Nombre del método de envío.
    nombre_metodo: {
        type: DataTypes.STRING(50),
        allowNull: false
    },

    // Descripción del servicio de envío.
    descripcion: {
        type: DataTypes.STRING(100)
    },

    // Valor del costo del envío.
    costo_envio: {
        type: DataTypes.DECIMAL(10, 2)
    },

    // Tiempo mínimo estimado de entrega (en días).
    dias_entrega_min: {
        type: DataTypes.INTEGER
    },

    // Estado del método de envío.
    // Generalmente:
    // 1 = Activo
    // 0 = Inactivo
    activo: {
        type: DataTypes.INTEGER
    },

    // Prioridad del método de envío.
    // Entre menor sea el número,
    // mayor prioridad tendrá.
    prioridad: {
        type: DataTypes.INTEGER
    },

    // Campo adicional definido en la base de datos.
    Metodos_Enviocol: {
        type: DataTypes.STRING(45)
    }

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre de la tabla en la base de datos.
    tableName: "metodo_envio",

    // Evita que Sequelize cree automáticamente
    // las columnas createdAt y updatedAt.
    timestamps: false,

    // Mantiene exactamente el nombre de la tabla.
    freezeTableName: true
});

// Exporta el modelo para utilizarlo
// en los controladores y relaciones.
export default metodoEnvio;