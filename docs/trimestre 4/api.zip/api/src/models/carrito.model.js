// Importa la conexión a la base de datos.
import sequelize from "../config/connect.db.js";

// Importa Model y DataTypes.
import { Model, DataTypes } from "sequelize";

// Clase Carrito.
class Carrito extends Model {}

// Inicializa el modelo.
Carrito.init(
  {
    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    id_carrito: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },

    // ==========================
    // LLAVE FORÁNEA
    // ==========================

    id_usuario: {
      type: DataTypes.UUID,
      allowNull: false,

      references: {
        model: "Users",
        key: "id_usuario",
      },

      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },

    // ==========================
    // FECHA
    // ==========================

    fecha_agregado: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },

  {
    sequelize,

    modelName: "carrito",

    tableName: "carrito",

    freezeTableName: true,

    timestamps: false,
  }
);

// Exporta el modelo.
export default Carrito;
