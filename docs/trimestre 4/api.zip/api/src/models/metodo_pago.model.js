// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos de Sequelize.
// Model permite crear modelos y DataTypes define el tipo de cada columna.
import { Model, DataTypes } from "sequelize";

// Crea la clase MetodoPago heredando de Model.
class MetodoPago extends Model {}

// Inicializa el modelo y define la estructura de la tabla.
MetodoPago.init({

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único del método de pago.
    id_medio_pago: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },

    // ==========================
    // INFORMACIÓN DEL MÉTODO
    // ==========================

    // Nombre del método de pago.
    // Ejemplos:
    // - Tarjeta de crédito
    // - PSE
    // - Nequi
    // - Efectivo
    nombre_metodo: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },

    // Tipo del método de pago.
    // Ejemplos:
    // - Electrónico
    // - Transferencia
    // - Tarjeta
    // - Efectivo
    tipo: {
        type: DataTypes.STRING(20),
        allowNull: false,
    },

    // Descripción del método de pago.
    descripcion: {
        type: DataTypes.STRING(200),
    },

    // Estado del método de pago.
    // true = Disponible
    // false = No disponible
    activo: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo en Sequelize.
    modelName: "MedioPago",

    // Nombre de la tabla en la base de datos.
    tableName: "medio_pago",

    // Evita que Sequelize genere automáticamente
    // las columnas createdAt y updatedAt.
    timestamps: false
});

// Exporta el modelo para utilizarlo
// en controladores y relaciones.
export default MetodoPago;