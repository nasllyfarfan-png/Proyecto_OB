// Importa la conexión a la base de datos configurada con Sequelize.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos disponibles en Sequelize.
import { Model, DataTypes } from "sequelize";

// Crea la clase UserStatus heredando de Model.
// Esta clase representa la tabla de estados de los usuarios.
class UserStatus extends Model {}

// Inicializa el modelo UserStatus y define la estructura de la tabla.
UserStatus.init({

    // Identificador único del estado del usuario.
    userStatus_id: {

        // Tipo de dato entero.
        type: DataTypes.INTEGER,

        // Incrementa automáticamente el valor en cada nuevo registro.
        autoIncrement: true,

        // Define este campo como la llave primaria.
        primaryKey: true
    },

    // Nombre del estado del usuario.
    // Ejemplos: Activo, Inactivo, Suspendido.
    userStatus_name: {

        // Tipo de dato texto.
        type: DataTypes.STRING,

        // Campo obligatorio.
        allowNull: false,

        // No permite nombres de estado repetidos.
        unique: true
    },

    // Descripción del estado del usuario.
    userStatus_description: {

        // Tipo de dato texto.
        type: DataTypes.STRING,

        // Campo opcional.
        allowNull: true,
    }

// Configuración adicional del modelo.
},{

    // Conexión a la base de datos utilizada por el modelo.
    sequelize,

    // Nombre interno del modelo dentro de Sequelize.
    modelName: "UserStatus"
});

// Exporta el modelo para utilizarlo en controladores,
// relaciones y otras partes del proyecto.
export default UserStatus;