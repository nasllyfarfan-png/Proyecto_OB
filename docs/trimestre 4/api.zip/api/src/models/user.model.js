// Importa la conexión a la base de datos.
import sequelize from "../config/connect.db.js";

// Importa Model y DataTypes desde Sequelize.
import { Model, DataTypes } from "sequelize";

// Clase User.
class User extends Model {}

// Inicializa el modelo.
User.init(
  {
    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    id_usuario: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
      allowNull: false,
    },

    // ==========================
    // USUARIO
    // ==========================

    user_user: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },

    // ==========================
    // CONTRASEÑA
    // ==========================

    user_password: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    // ==========================
    // ESTADO DEL USUARIO
    // ==========================

    userStatus_fk: {
      type: DataTypes.INTEGER,
      allowNull: false,

      references: {
        model: "UserStatuses",
        key: "userStatus_id",
      },

      onDelete: "RESTRICT",
      onUpdate: "CASCADE",
    },

    // ==========================
    // ROL
    // ==========================

    role_fk: {
      type: DataTypes.INTEGER,
      allowNull: false,

      references: {
        model: "Roles",
        key: "role_id",
      },

      onDelete: "RESTRICT",
      onUpdate: "CASCADE",
    },
  },

  {
    sequelize,

    modelName: "User",

    // IMPORTANTE:
    // Hace que Sequelize utilice exactamente esta tabla.
    tableName: "Users",

    freezeTableName: true,

    timestamps: false,
  }
);

// Exporta el modelo.
export default User;
