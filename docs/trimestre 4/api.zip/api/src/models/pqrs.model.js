// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos de Sequelize.
// Model permite crear modelos y DataTypes define el tipo de cada columna.
import { Model, DataTypes } from "sequelize";

// Crea la clase Pqrs heredando de Model.
class Pqrs extends Model {}

// Inicializa el modelo y define la estructura de la tabla.
Pqrs.init({

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único de la PQRS.
    id_pqrs: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },

    // ==========================
    // LLAVES FORÁNEAS
    // ==========================

    // Identificador de la venta relacionada con la PQRS.
    // Puede ser nulo cuando la solicitud no esté asociada a una compra.
    id_venta: {
        type: DataTypes.INTEGER,
        allowNull: true
    },

    // Identificador del usuario que registra la PQRS.
    id_usuario: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // ==========================
    // DATOS DEL USUARIO
    // ==========================

    // Nombre del usuario.
    nombre: {
        type: DataTypes.STRING(100),
        allowNull: false
    },

    // Apellido del usuario.
    apellido: {
        type: DataTypes.STRING(100),
        allowNull: false
    },

    // Correo electrónico del usuario.
    correo: {
        type: DataTypes.STRING(100),
        allowNull: false
    },

    // Número telefónico del usuario.
    telefono: {
        type: DataTypes.STRING(20),
        allowNull: false
    },

    // ==========================
    // INFORMACIÓN DE LA PQRS
    // ==========================

    // Tipo de solicitud.
    // Ejemplos:
    // - Petición
    // - Queja
    // - Reclamo
    // - Sugerencia
    tipo_pqrs: {
        type: DataTypes.STRING(20),
        allowNull: false
    },

    // Mensaje enviado por el usuario.
    mensaje_pqrs: {
        type: DataTypes.STRING(500),
        allowNull: false
    },

    // Respuesta generada por el administrador.
    // Inicialmente puede permanecer vacía.
    respuesta_pqrs: {
        type: DataTypes.STRING(500),
        allowNull: true
    },

    // Fecha de creación de la PQRS.
    fecha_pqrs: {
        type: DataTypes.DATE,
        allowNull: false
    },

    // Fecha en que se respondió la PQRS.
    fecha_respuesta: {
        type: DataTypes.DATE,
        allowNull: true
    },

    // Estado actual de la PQRS.
    // Ejemplos:
    // Pendiente
    // En proceso
    // Respondida
    // Cerrada
    estado_pqrs: {
        type: DataTypes.STRING(20),
        allowNull: false
    }

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo.
    modelName: "Pqrs",

    // Nombre de la tabla en la base de datos.
    tableName: "Pqrs",

    // Evita que Sequelize cree automáticamente
    // las columnas createdAt y updatedAt.
    timestamps: false
});

// Exporta el modelo para utilizarlo
// en los controladores y relaciones.
export default Pqrs;