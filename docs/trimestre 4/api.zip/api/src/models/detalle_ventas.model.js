// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos de Sequelize.
// Model permite crear modelos y DataTypes define el tipo de cada columna.
import { Model, DataTypes } from "sequelize";

// Crea la clase DetalleVentas heredando de Model.
class DetalleVentas extends Model {}

// Inicializa el modelo y define la estructura de la tabla.
DetalleVentas.init({

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único de cada detalle de venta.
    id_detalle: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    // ==========================
    // LLAVES FORÁNEAS
    // ==========================

    // Identificador de la venta a la que pertenece el producto.
    id_venta: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // Identificador del producto vendido.
    id_producto: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // ==========================
    // INFORMACIÓN DEL PRODUCTO
    // ==========================

    // Talla del producto vendido.
    talla: {
        type: DataTypes.STRING(10)
    },

    // Cantidad de unidades vendidas.
    cantidad: {
        type: DataTypes.INTEGER
    },

    // Color seleccionado del producto.
    color: {
        type: DataTypes.STRING(30)
    },

    // Precio unitario del producto.
    precio_unitario: {
        type: DataTypes.DECIMAL(12, 2)
    },

    // Valor total correspondiente a este producto.
    // Generalmente se calcula como:
    // cantidad × precio_unitario
    subtotal: {
        type: DataTypes.DECIMAL(14, 2)
    }

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo.
    modelName: "DetalleVentas",

    // Nombre de la tabla en la base de datos.
    tableName: "Detalle_Ventas",

    // Evita que Sequelize cree automáticamente
    // las columnas createdAt y updatedAt.
    timestamps: false,

    // Conserva exactamente el nombre de la tabla,
    // evitando que Sequelize lo pluralice.
    freezeTableName: true
});

// Exporta el modelo para utilizarlo
// en los controladores y relaciones.
export default DetalleVentas;