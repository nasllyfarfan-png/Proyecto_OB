// Importa la conexión a la base de datos configurada con Sequelize.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos disponibles en Sequelize.
import { Model, DataTypes } from "sequelize";

// Crea la clase Ventas heredando de Model.
// Esta clase representa la tabla de ventas del sistema.
class Ventas extends Model {}

// Inicializa el modelo Ventas y define la estructura de la tabla.
Ventas.init(
{

    // Identificador único de cada venta.
    id_ventas: {

        // Tipo de dato entero.
        type: DataTypes.INTEGER,

        // Se incrementa automáticamente.
        autoIncrement: true,

        // Define este campo como llave primaria.
        primaryKey: true
    },

    // Identificador del usuario que realizó la compra.
    id_usuario: {

        // Tipo entero.
        type: DataTypes.INTEGER,

        // Campo obligatorio.
        allowNull: false
    },

    // Llave foránea del método de pago utilizado.
    id_medio_pago: {

        // Tipo entero.
        type: DataTypes.INTEGER,

        // Campo obligatorio.
        allowNull: false
    },

    // Llave foránea del método de envío seleccionado.
    id_medio_envio: {

        // Tipo entero.
        type: DataTypes.INTEGER,

        // Campo obligatorio.
        allowNull: false
    },

    // Número telefónico del cliente.
    telefono: {

        // Texto con máximo 20 caracteres.
        type: DataTypes.STRING(20),

        // Campo obligatorio.
        allowNull: false
    },

    // Dirección donde será enviado el pedido.
    direccion_envio: {

        // Texto con máximo 200 caracteres.
        type: DataTypes.STRING(200),

        // Campo obligatorio.
        allowNull: false
    },

    // Ciudad de destino del pedido.
    ciudad: {

        // Texto con máximo 50 caracteres.
        type: DataTypes.STRING(50),

        // Campo obligatorio.
        allowNull: false
    },

    // Fecha en la que se realizó la venta.
    fecha_venta: {

        // Tipo fecha y hora.
        type: DataTypes.DATE,

        // Campo obligatorio.
        allowNull: false
    },

    // Valor total de los productos antes del envío.
    subtotal: {

        // Número decimal con hasta 14 dígitos y 2 decimales.
        type: DataTypes.DECIMAL(14,2),

        // Campo obligatorio.
        allowNull: false
    },

    // Costo correspondiente al envío.
    costo_envio: {

        // Número decimal con hasta 10 dígitos y 2 decimales.
        type: DataTypes.DECIMAL(10,2),

        // Campo obligatorio.
        allowNull: false
    },

    // Valor total de la compra (subtotal + envío).
    total: {

        // Número decimal con hasta 14 dígitos y 2 decimales.
        type: DataTypes.DECIMAL(14,2),

        // Campo obligatorio.
        allowNull: false
    },

    // Estado actual de la venta.
    // Ejemplos: Pendiente, Pagada, Enviada, Cancelada.
    estado_venta: {

        // Tipo texto.
        type: DataTypes.STRING(20),

        // Campo obligatorio.
        allowNull: false
    }

},
{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo.
    modelName: "Ventas",

    // Nombre real de la tabla en la base de datos.
    tableName: "ventas",

    // Desactiva la creación automática de createdAt y updatedAt.
    timestamps: false

});

// Exporta el modelo para poder utilizarlo
// en controladores, relaciones y rutas.
export default Ventas;