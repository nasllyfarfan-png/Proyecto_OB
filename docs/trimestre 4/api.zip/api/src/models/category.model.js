// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos de Sequelize.
// Model permite crear modelos.
// DataTypes define el tipo de cada columna.
import { Model, DataTypes } from "sequelize";


// Crea la clase Category heredando de Model.
class Category extends Model {}


// Inicializa el modelo y define la estructura de la tabla.
Category.init({

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único de la categoría.
    category_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },


    // ==========================
    // INFORMACIÓN DE LA CATEGORÍA
    // ==========================

    // Nombre de la categoría.
    category_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    // Descripción de la categoría.
    category_description: {
        type: DataTypes.STRING,
    },

    // Estado de la categoría.
    // true = Activa
    // false = Inactiva
    category_status: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },

    // Imagen representativa de la categoría.
    category_image: {
        type: DataTypes.STRING(255)
    },

    // Código interno de la categoría.
    category_code: {
        type: DataTypes.STRING(50)
    },

    // Usuario o administrador que creó la categoría.
    category_created_by: {
        type: DataTypes.STRING(100)
    },

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo.
    modelName: "Category",

    // Nombre de la tabla en la base de datos.
    tableName: "Category",
});


// Exporta el modelo para utilizarlo
// en los controladores y relaciones.
export default Category;