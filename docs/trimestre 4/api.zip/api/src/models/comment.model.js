// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos de Sequelize.
// Model permite crear modelos y DataTypes define el tipo de cada columna.
import { Model, DataTypes } from "sequelize";

// Crea la clase Comment heredando de Model.
class Comment extends Model {}

// Inicializa el modelo y define la estructura de la tabla.
Comment.init(
{

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único de cada comentario.
    id_comment: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },

    // ==========================
    // LLAVES FORÁNEAS
    // ==========================

    // Identificador del usuario que realizó el comentario.
    id_usuarios: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // Identificador del producto al que pertenece el comentario.
    id_productos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // ==========================
    // INFORMACIÓN DEL COMENTARIO
    // ==========================

    // Calificación otorgada al producto.
    // Generalmente se utiliza una escala de 1 a 5.
    calificacion: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // Texto del comentario realizado por el usuario.
    comment: {
        type: DataTypes.STRING(300),
        allowNull: false
    },

    // Fecha en la que se realizó el comentario.
    fecha: {
        type: DataTypes.DATE,
        allowNull: false
    },

    // Estado del comentario.
    // Ejemplo:
    // Activo
    // Pendiente
    // Eliminado
    estado: {
        type: DataTypes.STRING(15),
        allowNull: false
    }

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo.
    modelName: "Comment",

    // Nombre de la tabla en la base de datos.
    tableName: "comment",

    // Evita que Sequelize cree automáticamente
    // las columnas createdAt y updatedAt.
    timestamps: false
}

);

// Exporta el modelo para utilizarlo
// en los controladores y relaciones.
export default Comment;