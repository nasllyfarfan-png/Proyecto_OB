// Importa los tipos de datos disponibles en Sequelize.
import { DataTypes } from "sequelize";

// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";


// Define el modelo Notificaciones utilizando sequelize.define().
const Notificaciones = sequelize.define(

  // Nombre interno del modelo.
  "Notificaciones",

  // ==========================
  // DEFINICIÓN DE LOS CAMPOS
  // ==========================

  {

    // Llave primaria de la tabla.
    // Identificador único de cada notificación.
    id_notificaciones: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },

    // Identificador del usuario que recibe la notificación.
    id_usuario: {
      type: DataTypes.UUID,
      allowNull: false
    },

    // Mensaje que contiene la notificación.
    mensaje: {
      type: DataTypes.STRING(200),
    },

    // Tipo de notificación.
    // Ejemplos:
    // - Compra
    // - Envío
    // - Promoción
    // - Sistema
    tipo: {
      type: DataTypes.STRING(20),
    },

    // Fecha y hora en la que fue creada la notificación.
    fecha_notificaciones: {
      type: DataTypes.DATE,
    },

    // Estado de la notificación.
    // Ejemplo:
    // 0 = No leída
    // 1 = Leída
    estado_notificaciones: {
      type: DataTypes.INTEGER,
    },
  },

  // ==========================
  // CONFIGURACIÓN DEL MODELO
  // ==========================

  {

    // Nombre de la tabla en la base de datos.
    tableName: "Notificaciones",

    // Evita que Sequelize cree automáticamente
    // las columnas createdAt y updatedAt.
    timestamps: false,
  }
);

// Exporta el modelo para utilizarlo
// en controladores y relaciones.
export default Notificaciones;