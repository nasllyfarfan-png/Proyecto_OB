// Importa DataTypes y Model desde Sequelize.
// DataTypes permite definir los tipos de datos de cada campo.
// Model es la clase base para crear modelos.
import { DataTypes, Model } from "sequelize";

// Importa la conexión configurada con la base de datos.
import sequelize from "../config/connect.db.js";


// Crea la clase Carritoitems heredando de Model.
class Carritoitems extends Model {}


// Inicializa el modelo y define la estructura de la tabla.
Carritoitems.init({

    // ==========================
    // LLAVE PRIMARIA
    // ==========================

    // Identificador único del registro.
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },


    // ==========================
    // LLAVES FORÁNEAS
    // ==========================

    // Hace referencia al carrito al que pertenece el producto.
    id_carrito: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // Hace referencia al producto agregado al carrito.
    id_productos: {
        type: DataTypes.INTEGER,
        allowNull: false
    },


    // ==========================
    // INFORMACIÓN DEL PRODUCTO
    // ==========================

    // Talla seleccionada por el cliente.
    talla: {
        type: DataTypes.STRING(10),
        allowNull: false
    },

    // Cantidad del producto agregada al carrito.
    cantidad: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    // Color seleccionado del producto.
    color: {
        type: DataTypes.STRING(30),
        allowNull: false
    },

    // Precio individual del producto.
    precio_unitario: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false
    },

    // Valor total del producto
    // (cantidad × precio unitario).
    subtotal: {
        type: DataTypes.DECIMAL(14, 2),
        allowNull: false
    }

},

// ==========================
// CONFIGURACIÓN DEL MODELO
// ==========================

{

    // Conexión con la base de datos.
    sequelize,

    // Nombre interno del modelo.
    modelName: "carrito_items",

    // Nombre real de la tabla.
    tableName: "carrito_items",

    // Desactiva createdAt y updatedAt.
    timestamps: false,

    // Mantiene exactamente el nombre de la tabla.
    freezeTableName: true
});


// Exporta el modelo para utilizarlo
// en controladores y relaciones.
export default Carritoitems;