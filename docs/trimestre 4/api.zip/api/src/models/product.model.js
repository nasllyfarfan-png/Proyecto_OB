// Importa la clase Model y los tipos de datos de Sequelize
import sequelize from "../config/connect.db.js";
import { Model, DataTypes } from "sequelize";

// Crea la clase Product heredando de Model
class Product extends Model {}

// Inicializa el modelo Product
Product.init({

    // Llave primaria del producto
    product_id: {

        // Tipo de dato entero
        type: DataTypes.INTEGER,

        // Llave primaria
        primaryKey: true,

        // Se incrementa automáticamente
        autoIncrement: true
    },

    // Nombre del producto
    product_name: {

        // Tipo texto
        type: DataTypes.STRING,

        // Campo obligatorio
        allowNull: false,
    },

    // Descripción del producto
    product_description: {

        // Tipo texto
        type: DataTypes.STRING,

        // Puede quedar vacío
        allowNull: true,
    },

    // Precio del producto
    product_price: {

        // Número decimal con 10 dígitos y 2 decimales
        type: DataTypes.DECIMAL(10,2),

        // Campo obligatorio
        allowNull: false,
    },

    // Cantidad disponible en inventario
    product_stock: {

        // Tipo entero
        type: DataTypes.INTEGER,

        // Campo obligatorio
        allowNull: false,
    },

    // Llave foránea que relaciona el producto con una categoría
    category_fk: {

        // Tipo entero
        type: DataTypes.INTEGER,

        // Campo obligatorio
        allowNull: false,

        // Relación con la tabla Category
        references: {

            // Tabla relacionada
            model: "Category",

            // Llave primaria de la tabla Category
            key: "category_id",
        }
    },

    // Estado del producto
    product_status: {

        // Solo acepta estos valores
        type: DataTypes.ENUM(
            "active",
            "inactive",
            "out_of_stock"
        ),

        // Valor por defecto
        defaultValue: "active",
    }

},
{
    // Conexión a la base de datos
    sequelize,

    // Nombre de la tabla
    tableName: "Product"
});

// Exporta el modelo para utilizarlo en otros archivos
export default Product;