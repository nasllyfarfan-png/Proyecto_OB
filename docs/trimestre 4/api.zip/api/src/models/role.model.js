// Importa la conexión a la base de datos creada con Sequelize
import sequelize from "../config/connect.db.js";

// Importa la clase Model y los tipos de datos que ofrece Sequelize
import { Model, DataTypes } from "sequelize";

// Crea una clase llamada Role que hereda de Model.
// Esto permite representar la tabla Roles de la base de datos.
class Role extends Model {}

// Inicializa el modelo Role y define la estructura de la tabla.
Role.init({

    // Campo que identifica de forma única cada rol.
    role_id: {

        // Tipo de dato entero.
        type: DataTypes.INTEGER,

        // El valor aumenta automáticamente cada vez que se crea un registro.
        autoIncrement: true,

        // Indica que este campo es la llave primaria de la tabla.
        primaryKey: true
    },

    // Campo donde se almacena el nombre del rol.
    role_name: {

        // Tipo de dato texto.
        type: DataTypes.STRING,

        // No permite valores nulos.
        allowNull: false,

        // Evita que existan dos roles con el mismo nombre.
        unique: true
    },

    // Campo donde se almacena la descripción del rol.
    role_description: {

        // Tipo de dato texto.
        type: DataTypes.STRING,

        // Este campo es opcional.
        allowNull: true,
    }

// Configuración adicional del modelo.
},{

    // Indica la conexión que utilizará este modelo.
    sequelize,

    // Nombre interno del modelo dentro de Sequelize.
    modelName: "Role"
});

// Exporta el modelo para utilizarlo en otras partes del proyecto,
// como controladores, relaciones y rutas.
export default Role;