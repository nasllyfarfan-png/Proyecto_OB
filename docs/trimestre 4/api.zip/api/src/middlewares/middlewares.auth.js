// Importa la librería jsonwebtoken utilizando CommonJS.
// Esta librería permite verificar y decodificar tokens JWT.
const jwt = require("jsonwebtoken");


// ============================
// MIDDLEWARE DE VERIFICACIÓN DEL TOKEN
// ============================

// Función middleware encargada de validar el JWT enviado
// por el cliente antes de permitir el acceso a una ruta protegida.
const verificarToken = (req, res, next) => {

    // Obtiene el encabezado Authorization de la petición.
    // Normalmente tiene el formato:
    // Bearer eyJhbGciOiJIUzI1NiIs...
    const authHeader = req.headers.authorization;

    // Verifica si el cliente envió el token.
    if (!authHeader) {

        // Si no existe el encabezado Authorization,
        // devuelve un error de autenticación.
        return res.status(401).json({
            mensaje: "Token no proporcionado"
        });
    }

    // Separa la palabra "Bearer" del token.
    // El método split() divide el texto por espacios.
    // La posición [1] contiene únicamente el JWT.
    const token = authHeader.split(" ")[1];

    try {

        // Verifica que el token sea válido utilizando
        // la clave secreta almacenada en el archivo .env.
        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        // Guarda la información del usuario obtenida
        // del token dentro del objeto req.
        // Esto permite acceder a ella en los siguientes
        // middlewares o controladores.
        req.usuario = decoded;

        // Continúa la ejecución de la siguiente función
        // del flujo de Express.
        next();

    } catch (error) {

        // Si el token es inválido, fue modificado
        // o ya expiró, responde con un error 401.
        return res.status(401).json({
            mensaje: "Token inválido"
        });

    }

};

// Exporta el middleware utilizando CommonJS
// para que pueda ser utilizado en otros archivos.
module.exports = verificarToken;