// Importa la librería jsonwebtoken para verificar y decodificar
// los tokens JWT enviados por el cliente.
import jwt from "jsonwebtoken";


// ============================
// MIDDLEWARE DE VERIFICACIÓN JWT
// ============================

// Función middleware que verifica si el usuario
// posee un token válido antes de permitir el acceso
// a una ruta protegida.
const verifyToken = (req, res, next) => {

    // Muestra en la consola el contenido del encabezado Authorization.
    // Es útil para realizar pruebas y depuración.
    console.log("Authorization:", req.headers.authorization);

    try {

        // Obtiene el token enviado en el encabezado Authorization.
        // Generalmente llega con el formato:
        // Bearer eyJhbGciOiJIUzI1NiIs...
        let token = req.headers.authorization;

        // Verifica si el cliente envió un token.
        if (!token) {

            // Si no existe el token, responde con error 401
            // indicando que el usuario no está autenticado.
            return res.status(401).json({
                error: "Token not provided"
            });
        }

        // Separa el texto "Bearer" del token real.
        // split(" ") genera un arreglo:
        // ["Bearer", "eyJhbGciOiJIUzI1NiIs..."]
        // Se toma únicamente la segunda posición.
        token = token.split(" ")[1];

        // Verifica que el token sea válido utilizando
        // la clave secreta almacenada en el archivo .env.
        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        // Guarda la información decodificada del usuario
        // dentro del objeto req para que pueda utilizarse
        // en los siguientes middlewares o controladores.
        req.user = decoded;

        // Continúa con la siguiente función
        // (middleware o controlador).
        next();

    } catch (error) {

        // Si ocurre cualquier error (token vencido,
        // inválido o alterado), devuelve un error 401.
        return res.status(401).json({
            error: "Invalid token"
        });
    }
};


// Exporta el middleware para poder utilizarlo
// en las rutas protegidas.
export default verifyToken;