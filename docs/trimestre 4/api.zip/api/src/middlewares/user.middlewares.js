// Importa la utilidad schema desde la librería Joi.
// (En este archivo realmente no se utiliza, por lo que esta línea
// puede eliminarse sin afectar el funcionamiento).
import { schema } from "@hapi/joi/lib/compile.js";


// Exporta una función que recibe como parámetro un esquema de validación.
// Ese esquema normalmente se crea con Joi.
export default (schema) => {

    // Retorna un middleware de Express.
    // Este middleware se ejecutará antes del controlador.
    return async (req, res, next) => {

        try {

            // Valida los datos enviados por el cliente
            // (req.body) utilizando el esquema recibido.
            //
            // Si los datos cumplen todas las reglas,
            // validateAsync() no genera errores.
            await schema.validateAsync(req.body);

            // Si la validación fue correcta,
            // continúa con el siguiente middleware
            // o con el controlador.
            next();

        } catch (err) {

            // Si la validación falla,
            // responde con el mensaje de error generado por Joi.
            res.send(err.message);

        }

    }
}