// Importa el framework Express para crear el servidor y las rutas
import express from 'express';

// Importa Morgan para mostrar en la consola las peticiones HTTP
import morgan from "morgan";

// Importa CORS para permitir la comunicación entre el frontend y el backend
import cors from 'cors';

// Importa cookie-parser para leer las cookies enviadas por el navegador
import cookieParser from 'cookie-parser';


// ============================
// IMPORTACIÓN DE RUTAS
// ============================

// Importa las rutas de usuarios
import userRouter from "../routers/user.router.js";

// Importa las rutas de estados de usuario
import userStatusRouter from "../routers/userStatus.router.js";

// Importa las rutas de roles
import roleRouter from "../routers/role.router.js";

// Importa las rutas de productos
import productRouter from "../routers/product.router.js";

// Importa las rutas de categorías
import categoryRouter from "../routers/category.router.js";

// Importa las rutas de comentarios
import commentRouter from "../routers/comment.router.js";

// Importa las rutas de PQRS
import pqrsRouter from "../routers/pqrs.router.js";

// Importa las rutas de ventas
import ventasRouter from "../routers/ventas.router.js";

// Importa las rutas de métodos de pago
import metodoPagoRouter from "../routers/metodo_pago.router.js";

// Importa las rutas de métodos de envío
import metodoenvioRouter from "../routers/metodo_envio.router.js";

// Importa las rutas del detalle de ventas
import detalleVentasRouter from "../routers/detalle_ventas.router.js";

// Importa las rutas del carrito
import carritoRouter from "../routers/carrito.router.js";

// Importa las rutas de los productos del carrito
import carritoitemsRouter from "../routers/carrito_items.router.js";

// Importa las rutas de notificaciones
import notificacionesRouter from "../routers/notificaciones.router.js";


// ============================
// CREACIÓN DEL SERVIDOR
// ============================

// Crea una instancia de la aplicación Express
const app = express();


// ============================
// MIDDLEWARES GLOBALES
// ============================

// Configura CORS para permitir solicitudes desde el frontend
app.use(cors({

    // Dirección del frontend que tiene permiso para consumir la API
    origin: 'http://localhost:5173',

    // Permite enviar cookies y credenciales
    credentials: true
}));

// Muestra en la consola todas las peticiones realizadas al servidor
app.use(morgan("dev"));

// Permite recibir datos en formato JSON
app.use(express.json());

// Permite leer las cookies enviadas por el navegador
app.use(cookieParser());


// ============================
// REGISTRO DE RUTAS
// ============================

// Todas las rutas tendrán el prefijo /api/v1

// Activa las rutas relacionadas con usuarios
app.use("/api/v1", userRouter);

// Activa las rutas relacionadas con estados de usuario
app.use("/api/v1", userStatusRouter);

// Activa las rutas relacionadas con roles
app.use("/api/v1", roleRouter);

// Activa las rutas relacionadas con productos
app.use("/api/v1", productRouter);

// Activa las rutas relacionadas con categorías
app.use("/api/v1", categoryRouter);

// Activa las rutas relacionadas con comentarios
app.use("/api/v1", commentRouter);

// Activa las rutas relacionadas con PQRS
app.use("/api/v1", pqrsRouter);

// Activa las rutas relacionadas con ventas
app.use("/api/v1", ventasRouter);

// Activa las rutas relacionadas con métodos de pago
app.use("/api/v1", metodoPagoRouter);

// Activa las rutas relacionadas con métodos de envío
app.use("/api/v1", metodoenvioRouter);

// Activa las rutas relacionadas con detalle de ventas
app.use("/api/v1", detalleVentasRouter);

// Activa las rutas relacionadas con el carrito
app.use("/api/v1", carritoRouter);

// Activa las rutas relacionadas con los productos del carrito
app.use("/api/v1/carrito_items", carritoitemsRouter);

// Activa las rutas relacionadas con notificaciones
app.use("/api/v1/notificaciones", notificacionesRouter);


// ============================
// RUTA PARA ENDPOINTS NO ENCONTRADOS
// ============================

// Si el usuario solicita una ruta que no existe,
// se ejecutará este middleware
app.use((req, res) => {

    // Devuelve un código HTTP 404
    res.status(404).json({

        // Mensaje indicando que el endpoint no existe
        message: "Endpoint not found"
    });
});


// ============================
// EXPORTACIÓN DE LA APLICACIÓN
// ============================

// Exporta la aplicación para utilizarla en server.js
export default app;