// Importa la conexión configurada con la base de datos
import sequelize from "../config/connect.db.js";


// ============================
// IMPORTACIÓN DE MODELOS
// ============================

// Importa el modelo Estado de Usuario
import UserStatus from "../models/userStatus.model.js";

// Importa el modelo Rol
import Role from "../models/role.model.js";

// Importa el modelo Usuario
import User from "../models/user.model.js";

// Importa el modelo Producto
import Product from "../models/product.model.js";

// Importa el modelo Categoría
import Category from "../models/category.model.js";

// Importa el modelo Comentario
import Comment from "../models/comment.model.js";

// Importa el modelo PQRS
import Pqrs from "../models/pqrs.model.js";

// Importa el modelo Ventas
import Ventas from "../models/ventas.model.js";

// Importa el modelo Método de Pago
import MetodoPago from "../models/metodo_pago.model.js";

// Importa el modelo Método de Envío
import MetodoEnvio from "../models/metodo_envio.model.js";

// Importa el modelo Detalle de Ventas
import DetalleVentas from "../models/detalle_ventas.model.js";

// Importa el modelo Carrito
import Carrito from "../models/carrito.model.js";

// Importa el modelo Productos del Carrito
import CarritoItems from "../models/carrito_items.model.js";

// Importa el modelo Notificaciones
import notificaciones from "../models/notificaciones.model.js";


// ============================
// FUNCIÓN PARA INICIALIZAR
// TODAS LAS RELACIONES
// ============================

export const modelApp = function initModels(select) {

    // Solo crea las relaciones si select es verdadero
    if (select) {

        // ============================
        // USER STATUS 1 ---- N USER
        // ============================

        // Un estado puede tener muchos usuarios
        UserStatus.hasMany(User, {
            foreignKey: {
                name: "userStatus_fk",
                field: "userStatus_fk",
                allowNull: true
            }
        });

        // Un usuario pertenece a un estado
        User.belongsTo(UserStatus, {
            foreignKey: {
                name: "userStatus_fk",
                field: "userStatus_fk",
                allowNull: true
            }
        });


        // ============================
        // ROLE 1 ---- N USER
        // ============================

        // Un rol puede tener muchos usuarios
        Role.hasMany(User, {
            foreignKey: {
                name: "role_fk",
                field: "role_fk",
                allowNull: true
            }
        });

        // Un usuario pertenece a un rol
        User.belongsTo(Role, {
            foreignKey: {
                name: "role_fk",
                field: "role_fk",
                allowNull: true
            }
        });


        // ============================
        // USER 1 ---- N CARRITO
        // ============================

        // Un usuario puede tener varios carritos
        User.hasMany(Carrito, {
            foreignKey: {
                name: "id_usuario",
                allowNull: false
            }
        });

        // Un carrito pertenece a un usuario
        Carrito.belongsTo(User, {
            foreignKey: {
                name: "id_usuario",
                allowNull: false
            }
        });


        // ============================
        // CARRITO 1 ---- N ITEMS
        // ============================

        // Un carrito contiene muchos productos
        Carrito.hasMany(CarritoItems, {
            foreignKey: {
                name: "id_carrito",
                field: "id_carrito",
                allowNull: false
            }
        });

        // Cada producto del carrito pertenece a un carrito
        CarritoItems.belongsTo(Carrito, {
            foreignKey: {
                name: "id_carrito",
                field: "id_carrito",
                allowNull: false
            }
        });


        // ============================
        // PRODUCTO 1 ---- N ITEMS
        // ============================

        // Un producto puede aparecer en muchos carritos
        Product.hasMany(CarritoItems, {
            foreignKey: {
                name: "id_productos",
                field: "id_productos",
                allowNull: false
            }
        });

        // Cada producto del carrito pertenece a un producto
        CarritoItems.belongsTo(Product, {
            foreignKey: {
                name: "id_productos",
                field: "id_productos",
                allowNull: false
            }
        });


        // ============================
        // CATEGORIA 1 ---- N PRODUCTOS
        // ============================

        // Una categoría tiene muchos productos
        Category.hasMany(Product, {
            foreignKey: {
                name: "category_fk",
                field: "category_fk",
                allowNull: true
            }
        });

        // Un producto pertenece a una categoría
        Product.belongsTo(Category, {
            foreignKey: {
                name: "category_fk",
                field: "category_fk",
                allowNull: true
            }
        });


        // ============================
        // PRODUCTO 1 ---- N COMENTARIOS
        // ============================

        // Un producto puede tener muchos comentarios
        Product.hasMany(Comment, {
            foreignKey: {
                name: "id_productos",
                field: "id_productos",
                allowNull: false
            }
        });

        // Cada comentario pertenece a un producto
        Comment.belongsTo(Product, {
            foreignKey: {
                name: "id_productos",
                field: "id_productos",
                allowNull: false
            }
        });


        // ============================
        // METODO PAGO 1 ---- N VENTAS
        // ============================

        // Un método de pago puede utilizarse en muchas ventas
        MetodoPago.hasMany(Ventas, {
            foreignKey: {
                name: "id_medio_pago",
                field: "id_medio_pago",
                allowNull: false
            }
        });

        // Cada venta utiliza un método de pago
        Ventas.belongsTo(MetodoPago, {
            foreignKey: {
                name: "id_medio_pago",
                field: "id_medio_pago",
                allowNull: false
            }
        });


        // ============================
        // METODO ENVIO 1 ---- N VENTAS
        // ============================

        // Un método de envío puede estar en muchas ventas
        MetodoEnvio.hasMany(Ventas, {
            foreignKey: {
                name: "id_medio_envio",
                field: "id_medio_envio",
                allowNull: false
            }
        });

        // Cada venta utiliza un método de envío
        Ventas.belongsTo(MetodoEnvio, {
            foreignKey: {
                name: "id_medio_envio",
                field: "id_medio_envio",
                allowNull: false
            }
        });


        // ============================
        // VENTA 1 ---- N PQRS
        // ============================

        // Una venta puede generar varias PQRS
        Ventas.hasMany(Pqrs, {
            foreignKey: {
                name: "id_venta",
                field: "id_venta",
                allowNull: true
            }
        });

        // Cada PQRS pertenece a una venta
        Pqrs.belongsTo(Ventas, {
            foreignKey: {
                name: "id_venta",
                field: "id_venta",
                allowNull: true
            }
        });


        // ============================
        // VENTA 1 ---- N DETALLE VENTAS
        // ============================

        // Una venta tiene varios productos vendidos
        Ventas.hasMany(DetalleVentas, {
            foreignKey: {
                name: "id_venta",
                field: "id_venta",
                allowNull: false
            }
        });

        // Cada detalle pertenece a una venta
        DetalleVentas.belongsTo(Ventas, {
            foreignKey: {
                name: "id_venta",
                field: "id_venta",
                allowNull: false
            }
        });


        // ============================
        // PRODUCTO 1 ---- N DETALLE VENTAS
        // ============================

        // Un producto puede aparecer en muchos detalles de venta
        Product.hasMany(DetalleVentas, {
            foreignKey: {
                name: "id_producto",
                field: "id_producto",
                allowNull: false
            }
        });

        // Cada detalle pertenece a un producto
        DetalleVentas.belongsTo(Product, {
            foreignKey: {
                name: "id_producto",
                field: "id_producto",
                allowNull: false
            }
        });


        // ============================
        // USER 1 ---- N NOTIFICACIONES
        // ============================

        // Un usuario puede recibir muchas notificaciones
        User.hasMany(notificaciones, {
            foreignKey: "Usuarios_id_usuarios"
        });

        // Cada notificación pertenece a un usuario
        notificaciones.belongsTo(User, {
            foreignKey: "Usuarios_id_usuarios"
        });


        // ============================
        // SINCRONIZAR MODELOS
        // ============================

        // Sincroniza todos los modelos con la base de datos
        sequelize.sync({

            // No elimina las tablas existentes
            force: false,

            // No modifica automáticamente la estructura de las tablas
            alter: false
        });
    }
};