// Importa la clase Router desde Express.
// Router permite organizar las rutas de la aplicación en módulos independientes.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Este middleware protege las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador del carrito.
// Cada función realiza una operación CRUD sobre la tabla carrito.
import {
    createCarrito,
    showCarrito,
    showIdCarrito,
    updateCarrito,
    deleteCarrito
} from "../controller/carrito.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DEL CARRITO
   ========================== */

// Ruta para crear un nuevo carrito.
// Método HTTP: POST
// Endpoint: /api/v1/carrito
// Actualmente no requiere autenticación.
router.post("/carrito", createCarrito);

// Ruta para obtener todos los carritos registrados.
// Método HTTP: GET
// Endpoint: /api/v1/carrito
// Requiere un token JWT válido.
router.get("/carrito", verifyToken, showCarrito);

// Ruta para consultar un carrito específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/carrito/:id
// Requiere autenticación mediante JWT.
router.get("/carrito/:id", verifyToken, showIdCarrito);

// Ruta para actualizar la información de un carrito.
// Método HTTP: PUT
// Endpoint: /api/v1/carrito/:id
// Requiere autenticación mediante JWT.
router.put("/carrito/:id", verifyToken, updateCarrito);

// Ruta para eliminar un carrito.
// Método HTTP: DELETE
// Endpoint: /api/v1/carrito/:id
// Requiere autenticación mediante JWT.
router.delete("/carrito/:id", verifyToken, deleteCarrito);

// Exporta el enrutador para utilizarlo en el archivo principal (app.js).
export default router;