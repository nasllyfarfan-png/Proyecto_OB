// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de roles.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de roles.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createRole,
    showRole,
    showIdRole,
    updateRole,
    deleteRole
} from "../controller/role.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE ROLES
   ========================== */

// Ruta para crear un nuevo rol.
// Método HTTP: POST
// Endpoint: /api/v1/role
// Actualmente no requiere autenticación.
router.post("/role", createRole);

// Ruta para obtener todos los roles.
// Método HTTP: GET
// Endpoint: /api/v1/role
// Requiere un token JWT válido.
router.get("/role", verifyToken, showRole);

// Ruta para consultar un rol específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/role/:id
// Requiere autenticación mediante JWT.
router.get("/role/:id", verifyToken, showIdRole);

// Ruta para actualizar un rol existente.
// Método HTTP: PUT
// Endpoint: /api/v1/role/:id
// Requiere autenticación mediante JWT.
router.put("/role/:id", verifyToken, updateRole);

// Ruta para eliminar un rol.
// Método HTTP: DELETE
// Endpoint: /api/v1/role/:id
// Requiere autenticación mediante JWT.
router.delete("/role/:id", verifyToken, deleteRole);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;