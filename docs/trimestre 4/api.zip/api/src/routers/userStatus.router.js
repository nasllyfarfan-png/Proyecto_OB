// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de estados de usuario.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de estados de usuario.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createUserStatus,
    showUserStatus,
    showIdUserStatus,
    updateUserStatus,
    deleteUserStatus
} from "../controller/userStatus.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE ESTADOS DE USUARIO
   ========================== */

// Ruta para crear un nuevo estado de usuario.
// Método HTTP: POST
// Endpoint: /api/v1/userStatus
// Actualmente no requiere autenticación.
router.post("/userStatus", createUserStatus);

// Ruta para obtener todos los estados de usuario.
// Método HTTP: GET
// Endpoint: /api/v1/userStatus
// Requiere un token JWT válido.
router.get("/userStatus", verifyToken, showUserStatus);

// Ruta para consultar un estado de usuario específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/userStatus/:id
// Requiere autenticación mediante JWT.
router.get("/userStatus/:id", verifyToken, showIdUserStatus);

// Ruta para actualizar un estado de usuario existente.
// Método HTTP: PUT
// Endpoint: /api/v1/userStatus/:id
// Requiere autenticación mediante JWT.
router.put("/userStatus/:id", verifyToken, updateUserStatus);

// Ruta para eliminar un estado de usuario.
// Método HTTP: DELETE
// Endpoint: /api/v1/userStatus/:id
// Requiere autenticación mediante JWT.
router.delete("/userStatus/:id", verifyToken, deleteUserStatus);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;