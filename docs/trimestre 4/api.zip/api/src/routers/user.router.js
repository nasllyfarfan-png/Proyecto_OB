// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de usuarios.
import { Router } from "express";

// Importa el controlador de usuarios.
// Contiene la lógica para realizar las operaciones CRUD,
// así como el inicio y cierre de sesión.
import userController from "../controller/user.controller.js";

// Importa los esquemas de validación de usuarios.
import userSchema from "../schemes/user.schema.js";

// Importa el middleware encargado de validar los datos
// enviados en las peticiones utilizando Joi.
import userMiddleware from "../middlewares/user.middlewares.js";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE USUARIOS
   ========================== */

// Ruta para registrar un nuevo usuario.
// Método HTTP: POST
// Endpoint: /api/v1/user
// Valida los datos antes de crear el usuario.
// No requiere autenticación.
router.post(
    "/user",
    userMiddleware(userSchema.createUser),
    userController.createUser
);

// Ruta para obtener todos los usuarios.
// Método HTTP: GET
// Endpoint: /api/v1/user
// Requiere un token JWT válido.
router.get(
    "/user",
    verifyToken,
    userController.showUser
);

// Ruta para obtener un usuario específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/user/:id
// Requiere autenticación mediante JWT.
router.get(
    "/user/:id",
    verifyToken,
    userController.showUserId
);

// Ruta para actualizar la información de un usuario.
// Método HTTP: PUT
// Endpoint: /api/v1/user
// Valida los datos antes de actualizar.
// Requiere autenticación mediante JWT.
router.put(
    "/user",
    verifyToken,
    userMiddleware(userSchema.updateUser),
    userController.updateUser
);

// Ruta para eliminar un usuario.
// Método HTTP: DELETE
// Endpoint: /api/v1/user/:id
// Requiere autenticación mediante JWT.
router.delete(
    "/user/:id",
    verifyToken,
    userController.deleteUser
);

// Ruta para iniciar sesión.
// Método HTTP: POST
// Endpoint: /api/v1/user/login
// Genera un token JWT si las credenciales son correctas.
router.post(
    "/user/login",
    userController.loginUser
);

// Ruta para cerrar sesión.
// Método HTTP: POST
// Endpoint: /api/v1/user/logout
// Finaliza la sesión del usuario.
router.post(
    "/user/logout",
    userController.logoutUser
);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;