// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de categorías.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de categorías.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createCategory,
    showCategory,
    showIdCategory,
    updateCategory,
    deleteCategory
} from "../controller/category.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE CATEGORÍAS
   ========================== */

// Ruta para crear una nueva categoría.
// Método HTTP: POST
// Endpoint: /api/v1/category
// Actualmente no requiere autenticación.
router.post("/category", createCategory);

// Ruta para obtener todas las categorías.
// Método HTTP: GET
// Endpoint: /api/v1/category
// Requiere un token JWT válido.
router.get("/category", verifyToken, showCategory);

// Ruta para consultar una categoría específica mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/category/:id
// Requiere autenticación mediante JWT.
router.get("/category/:id", verifyToken, showIdCategory);

// Ruta para actualizar una categoría existente.
// Método HTTP: PUT
// Endpoint: /api/v1/category/:id
// Requiere autenticación mediante JWT.
router.put("/category/:id", verifyToken, updateCategory);

// Ruta para eliminar una categoría.
// Método HTTP: DELETE
// Endpoint: /api/v1/category/:id
// Requiere autenticación mediante JWT.
router.delete("/category/:id", verifyToken, deleteCategory);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;