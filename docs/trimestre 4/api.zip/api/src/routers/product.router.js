// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de productos.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de productos.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createProduct,
    showProduct,
    showIdProduct,
    updateProduct,
    deleteProduct
} from "../controller/product.Controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE PRODUCTOS
   ========================== */

// Ruta para crear un nuevo producto.
// Método HTTP: POST
// Endpoint: /api/v1/product
// Actualmente no requiere autenticación.
router.post("/product", createProduct);

// Ruta para obtener todos los productos.
// Método HTTP: GET
// Endpoint: /api/v1/product
// Requiere un token JWT válido.
router.get("/product", verifyToken, showProduct);

// Ruta para consultar un producto específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/product/:id
// Requiere autenticación mediante JWT.
router.get("/product/:id", verifyToken, showIdProduct);

// Ruta para actualizar un producto existente.
// Método HTTP: PUT
// Endpoint: /api/v1/product/:id
// Requiere autenticación mediante JWT.
router.put("/product/:id", verifyToken, updateProduct);

// Ruta para eliminar un producto.
// Método HTTP: DELETE
// Endpoint: /api/v1/product/:id
// Requiere autenticación mediante JWT.
router.delete("/product/:id", verifyToken, deleteProduct);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;