// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de métodos de pago.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de métodos de pago.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createMetodoPago,
    showMetodosPago,
    showIdMetodoPago,
    updateMetodoPago,
    deleteMetodoPago
} from "../controller/metodo_pago.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE MÉTODOS DE PAGO
   ========================== */

// Ruta para crear un nuevo método de pago.
// Método HTTP: POST
// Endpoint: /api/v1/metodo-pago
// Actualmente no requiere autenticación.
router.post("/metodo-pago", createMetodoPago);

// Ruta para obtener todos los métodos de pago.
// Método HTTP: GET
// Endpoint: /api/v1/metodo-pago
// Requiere un token JWT válido.
router.get("/metodo-pago", verifyToken, showMetodosPago);

// Ruta para consultar un método de pago específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/metodo-pago/:id
// Requiere autenticación mediante JWT.
router.get("/metodo-pago/:id", verifyToken, showIdMetodoPago);

// Ruta para actualizar un método de pago existente.
// Método HTTP: PUT
// Endpoint: /api/v1/metodo-pago/:id
// Requiere autenticación mediante JWT.
router.put("/metodo-pago/:id", verifyToken, updateMetodoPago);

// Ruta para eliminar un método de pago.
// Método HTTP: DELETE
// Endpoint: /api/v1/metodo-pago/:id
// Requiere autenticación mediante JWT.
router.delete("/metodo-pago/:id", verifyToken, deleteMetodoPago);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;