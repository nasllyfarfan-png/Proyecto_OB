// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de comentarios.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de comentarios.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createComment,
    showComment,
    showIdComment,
    updateComment,
    deleteComment
} from "../controller/comment.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE COMENTARIOS
   ========================== */

// Ruta para crear un nuevo comentario.
// Método HTTP: POST
// Endpoint: /api/v1/comment
// Actualmente no requiere autenticación.
router.post("/comment", createComment);

// Ruta para obtener todos los comentarios.
// Método HTTP: GET
// Endpoint: /api/v1/comment
// Requiere un token JWT válido.
router.get("/comment", verifyToken, showComment);

// Ruta para consultar un comentario específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/comment/:id
// Requiere autenticación mediante JWT.
router.get("/comment/:id", verifyToken, showIdComment);

// Ruta para actualizar un comentario existente.
// Método HTTP: PUT
// Endpoint: /api/v1/comment/:id
// Requiere autenticación mediante JWT.
router.put("/comment/:id", verifyToken, updateComment);

// Ruta para eliminar un comentario.
// Método HTTP: DELETE
// Endpoint: /api/v1/comment/:id
// Requiere autenticación mediante JWT.
router.delete("/comment/:id", verifyToken, deleteComment);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;