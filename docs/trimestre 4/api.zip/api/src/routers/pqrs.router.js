// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de PQRS.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de PQRS.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createPqrs,
    showPqrs,
    showIdPqrs,
    updatePqrs,
    deletePqrs
} from "../controller/pqrs.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE PQRS
   ========================== */

// Ruta para crear un nuevo registro de PQRS.
// Método HTTP: POST
// Endpoint: /api/v1/pqrs
// Actualmente no requiere autenticación.
router.post("/pqrs", createPqrs);

// Ruta para obtener todos los registros de PQRS.
// Método HTTP: GET
// Endpoint: /api/v1/pqrs
// Requiere un token JWT válido.
router.get("/pqrs", verifyToken, showPqrs);

// Ruta para consultar un registro de PQRS específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/pqrs/:id
// Requiere autenticación mediante JWT.
router.get("/pqrs/:id", verifyToken, showIdPqrs);

// Ruta para actualizar un registro de PQRS existente.
// Método HTTP: PUT
// Endpoint: /api/v1/pqrs/:id
// Requiere autenticación mediante JWT.
router.put("/pqrs/:id", verifyToken, updatePqrs);

// Ruta para eliminar un registro de PQRS.
// Método HTTP: DELETE
// Endpoint: /api/v1/pqrs/:id
// Requiere autenticación mediante JWT.
router.delete("/pqrs/:id", verifyToken, deletePqrs);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;