// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de ventas.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de ventas.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createVenta,
    showVentas,
    showIdVenta,
    updateVenta,
    deleteVenta
} from "../controller/ventas.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE VENTAS
   ========================== */

// Ruta para crear una nueva venta.
// Método HTTP: POST
// Endpoint: /api/v1/ventas
// Actualmente no requiere autenticación.
router.post("/ventas", createVenta);

// Ruta para obtener todas las ventas.
// Método HTTP: GET
// Endpoint: /api/v1/ventas
// Requiere un token JWT válido.
router.get("/ventas", verifyToken, showVentas);

// Ruta para consultar una venta específica mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/ventas/:id
// Requiere autenticación mediante JWT.
router.get("/ventas/:id", verifyToken, showIdVenta);

// Ruta para actualizar una venta existente.
// Método HTTP: PUT
// Endpoint: /api/v1/ventas/:id
// Requiere autenticación mediante JWT.
router.put("/ventas/:id", verifyToken, updateVenta);

// Ruta para eliminar una venta.
// Método HTTP: DELETE
// Endpoint: /api/v1/ventas/:id
// Requiere autenticación mediante JWT.
router.delete("/ventas/:id", verifyToken, deleteVenta);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;