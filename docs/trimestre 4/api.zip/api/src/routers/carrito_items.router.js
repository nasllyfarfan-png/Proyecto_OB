// Importa la clase Router desde Express.
// Router permite crear un conjunto de rutas independientes.
import { Router } from "express";

// Importa el middleware que verifica el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador encargadas de realizar
// las operaciones CRUD sobre los elementos del carrito.
import {
    createCarritoItem,
    showCarritoItems,
    showIdCarritoItem,
    updateCarritoItem,
    deleteCarritoItem
} from "../controller/carrito_items.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DEL CARRITO ITEMS
   ========================== */

// Ruta para crear un nuevo producto dentro del carrito.
// Método HTTP: POST
// Endpoint: /api/v1/carrito_items
// No requiere autenticación.
router.post("/", createCarritoItem);

// Ruta para obtener todos los productos agregados al carrito.
// Método HTTP: GET
// Endpoint: /api/v1/carrito_items
// Requiere un token JWT válido.
router.get("/", verifyToken, showCarritoItems);

// Ruta para consultar un producto específico del carrito mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/carrito_items/:id
// Requiere autenticación mediante JWT.
router.get("/:id", verifyToken, showIdCarritoItem);

// Ruta para actualizar un producto del carrito.
// Método HTTP: PUT
// Endpoint: /api/v1/carrito_items/:id
// Requiere autenticación mediante JWT.
router.put("/:id", verifyToken, updateCarritoItem);

// Ruta para eliminar un producto del carrito.
// Método HTTP: DELETE
// Endpoint: /api/v1/carrito_items/:id
// Requiere autenticación mediante JWT.
router.delete("/:id", verifyToken, deleteCarritoItem);

// Exporta el enrutador para que pueda utilizarse
// en el archivo principal de la aplicación (app.js).
export default router;