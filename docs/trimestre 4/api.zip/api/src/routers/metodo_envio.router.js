// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de métodos de envío.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de métodos de envío.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createMetodoEnvio,
    showMetodoEnvio,
    showIdMetodoEnvio,
    updateMetodoEnvio,
    deleteMetodoEnvio
} from "../controller/metodo_envio.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE MÉTODOS DE ENVÍO
   ========================== */

// Ruta para crear un nuevo método de envío.
// Método HTTP: POST
// Endpoint: /api/v1/metodo_envio
// Actualmente no requiere autenticación.
router.post("/metodo_envio", createMetodoEnvio);

// Ruta para obtener todos los métodos de envío.
// Método HTTP: GET
// Endpoint: /api/v1/metodo_envio
// Requiere un token JWT válido.
router.get("/metodo_envio", verifyToken, showMetodoEnvio);

// Ruta para consultar un método de envío específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/metodo_envio/:id
// Requiere autenticación mediante JWT.
router.get("/metodo_envio/:id", verifyToken, showIdMetodoEnvio);

// Ruta para actualizar un método de envío existente.
// Método HTTP: PUT
// Endpoint: /api/v1/metodo_envio/:id
// Requiere autenticación mediante JWT.
router.put("/metodo_envio/:id", verifyToken, updateMetodoEnvio);

// Ruta para eliminar un método de envío.
// Método HTTP: DELETE
// Endpoint: /api/v1/metodo_envio/:id
// Requiere autenticación mediante JWT.
router.delete("/metodo_envio/:id", verifyToken, deleteMetodoEnvio);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;