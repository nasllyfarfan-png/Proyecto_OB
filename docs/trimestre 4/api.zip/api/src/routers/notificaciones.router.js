// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de notificaciones.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de notificaciones.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
  createNotificaciones,
  showNotificaciones,
  showIdNotificaciones,
  updateNotificaciones,
  deleteNotificaciones,
} from "../controller/notificaciones.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE NOTIFICACIONES
   ========================== */

// Ruta para obtener todas las notificaciones.
// Método HTTP: GET
// Endpoint: /api/v1/notificaciones
// Requiere un token JWT válido.
router.get("/", verifyToken, showNotificaciones);

// Ruta para consultar una notificación específica mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/notificaciones/:id
// Requiere autenticación mediante JWT.
router.get("/:id", verifyToken, showIdNotificaciones);

// Ruta para crear una nueva notificación.
// Método HTTP: POST
// Endpoint: /api/v1/notificaciones
// Actualmente no requiere autenticación.
router.post("/", createNotificaciones);

// Ruta para actualizar una notificación existente.
// Método HTTP: PUT
// Endpoint: /api/v1/notificaciones/:id
// Requiere autenticación mediante JWT.
router.put("/:id", verifyToken, updateNotificaciones);

// Ruta para eliminar una notificación.
// Método HTTP: DELETE
// Endpoint: /api/v1/notificaciones/:id
// Requiere autenticación mediante JWT.
router.delete("/:id", verifyToken, deleteNotificaciones);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;