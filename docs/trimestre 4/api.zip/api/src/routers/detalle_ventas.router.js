// Importa la clase Router desde Express.
// Router permite organizar las rutas del módulo de detalles de ventas.
import { Router } from "express";

// Importa el middleware encargado de verificar el token JWT.
// Se utiliza para proteger las rutas que requieren autenticación.
import verifyToken from "../middlewares/jwt.middleware.js";

// Importa las funciones del controlador de detalles de ventas.
// Estas funciones contienen la lógica para realizar las operaciones CRUD.
import {
    createDetalleVenta,
    showDetalleVentas,
    showIdDetalleVenta,
    updateDetalleVenta,
    deleteDetalleVenta
} from "../controller/detalle_ventas.controller.js";

// Crea una nueva instancia del enrutador de Express.
const router = Router();

/* ==========================
   RUTAS DE DETALLE DE VENTAS
   ========================== */

// Ruta para crear un nuevo detalle de venta.
// Método HTTP: POST
// Endpoint: /api/v1/detalle_ventas
// Actualmente no requiere autenticación.
router.post("/detalle_ventas", createDetalleVenta);

// Ruta para obtener todos los detalles de ventas.
// Método HTTP: GET
// Endpoint: /api/v1/detalle_ventas
// Requiere un token JWT válido.
router.get("/detalle_ventas", verifyToken, showDetalleVentas);

// Ruta para consultar un detalle de venta específico mediante su ID.
// Método HTTP: GET
// Endpoint: /api/v1/detalle_ventas/:id
// Requiere autenticación mediante JWT.
router.get("/detalle_ventas/:id", verifyToken, showIdDetalleVenta);

// Ruta para actualizar un detalle de venta existente.
// Método HTTP: PUT
// Endpoint: /api/v1/detalle_ventas/:id
// Requiere autenticación mediante JWT.
router.put("/detalle_ventas/:id", verifyToken, updateDetalleVenta);

// Ruta para eliminar un detalle de venta.
// Método HTTP: DELETE
// Endpoint: /api/v1/detalle_ventas/:id
// Requiere autenticación mediante JWT.
router.delete("/detalle_ventas/:id", verifyToken, deleteDetalleVenta);

// Exporta el enrutador para que pueda ser utilizado
// en el archivo principal de la aplicación (app.js).
export default router;