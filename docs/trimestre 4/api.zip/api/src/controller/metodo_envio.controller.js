// Importa el modelo MetodoEnvio para realizar operaciones
// sobre la tabla metodos_envio de la base de datos
import metodoEnvioModel from "../models/metodo_envio.model.js";


// ============================
// CREAR MÉTODO DE ENVÍO
// ============================

// Exporta la función para crear un nuevo método de envío
export const createMetodoEnvio = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataMetodo = req.body;

        // Crea un nuevo registro en la tabla metodos_envio
        await metodoEnvioModel.create({

            // Guarda el nombre del método de envío
            nombre_metodo: dataMetodo.nombre_metodo,

            // Guarda la descripción del método
            descripcion: dataMetodo.descripcion,

            // Guarda el costo del envío
            costo_envio: dataMetodo.costo_envio,

            // Guarda el tiempo mínimo de entrega
            dias_entrega_min: dataMetodo.dias_entrega_min,

            // Guarda el estado del método (activo o inactivo)
            activo: dataMetodo.activo,

            // Guarda la prioridad del método
            prioridad: dataMetodo.prioridad,

            // Guarda el campo adicional definido en el modelo
            Metodos_Enviocol: dataMetodo.Metodos_Enviocol
        });

        // Devuelve una respuesta indicando que el método fue creado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Create Metodo Envio :)"
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODOS LOS MÉTODOS
// ============================

// Exporta la función para consultar todos los métodos de envío
export const showMetodoEnvio = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await metodoEnvioModel.sync();

        // Obtiene todos los métodos registrados
        const metodos = await metodoEnvioModel.findAll();

        // Devuelve la lista de métodos
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Metodos Envio :)",
            data: metodos
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR MÉTODO POR ID
// ============================

// Exporta la función para buscar un método de envío por su id
export const showIdMetodoEnvio = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await metodoEnvioModel.sync();

        // Obtiene el id enviado en la URL
        const { id } = req.params;

        // Busca el método correspondiente
        const metodo = await metodoEnvioModel.findOne({
            where: {

                // Condición de búsqueda
                id_metodos_envio: id
            }
        });

        // Devuelve el método encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Metodo Envio :)",
            data: metodo
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ACTUALIZAR MÉTODO DE ENVÍO
// ============================

// Exporta la función para actualizar un método de envío
export const updateMetodoEnvio = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Obtiene los nuevos datos enviados
        const dataMetodo = req.body;

        // Actualiza el registro correspondiente
        await metodoEnvioModel.update(
            {

                // Actualiza el nombre del método
                nombre_metodo: dataMetodo.nombre_metodo,

                // Actualiza la descripción
                descripcion: dataMetodo.descripcion,

                // Actualiza el costo del envío
                costo_envio: dataMetodo.costo_envio,

                // Actualiza el tiempo mínimo de entrega
                dias_entrega_min: dataMetodo.dias_entrega_min,

                // Actualiza el estado del método
                activo: dataMetodo.activo,

                // Actualiza la prioridad
                prioridad: dataMetodo.prioridad,

                // Actualiza el campo adicional
                Metodos_Enviocol: dataMetodo.Metodos_Enviocol
            },
            {

                // Indica qué registro será actualizado
                where: {
                    id_metodos_envio: id
                }
            }
        );

        // Devuelve una respuesta indicando que fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Metodo Envio :)"
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR MÉTODO DE ENVÍO
// ============================

// Exporta la función para eliminar un método de envío
export const deleteMetodoEnvio = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Elimina el registro correspondiente
        const metodo = await metodoEnvioModel.destroy({

            // Condición para eliminar
            where: {
                id_metodos_envio: id
            }
        });

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Metodo Envio :)",
            data: metodo
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};