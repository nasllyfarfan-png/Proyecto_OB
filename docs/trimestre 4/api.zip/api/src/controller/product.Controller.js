// Importa el modelo Product para realizar operaciones
// sobre la tabla productos de la base de datos
import productModel from "../models/product.model.js";

// Importa Faker para generar datos ficticios (aunque en este archivo no se utiliza)
import { faker } from "@faker-js/faker";

// Importa JWT para trabajar con tokens de autenticación
// (en este controlador tampoco se utiliza)
import jwt from "jsonwebtoken";


// ============================
// CREAR PRODUCTO
// ============================

// Exporta la función para crear un nuevo producto
export const createProduct = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataProduct = req.body;

        // Inserta un nuevo producto en la base de datos
        await productModel.create({

            // Guarda el nombre del producto
            product_name: dataProduct.product_name,

            // Guarda la descripción del producto
            product_description: dataProduct.product_description,

            // Guarda el precio
            product_price: dataProduct.product_price,

            // Guarda el stock disponible
            product_stock: dataProduct.product_stock,

            // Guarda el estado del producto
            product_status: dataProduct.product_status,

            // Guarda la categoría a la que pertenece
            category_fk: dataProduct.category_fk
        });

        // Devuelve una respuesta indicando que el producto fue creado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Create Product :)"
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// MOSTRAR TODOS LOS PRODUCTOS
// ============================

// Exporta la función para consultar todos los productos
export const showProduct = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await productModel.sync();

        // Obtiene todos los productos registrados
        const showProducts = await productModel.findAll();

        // Devuelve la lista de productos
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Product :)",
            data: showProducts,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// MOSTRAR PRODUCTO POR ID
// ============================

// Exporta la función para buscar un producto por su identificador
export const showIdProduct = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await productModel.sync();

        // Obtiene el id enviado por la URL
        const idProduct = req.params.id;

        // Busca el producto correspondiente
        const showIdProduct = await productModel.findOne({
            where: {

                // Condición de búsqueda
                product_id: idProduct,
            }
        });

        // Devuelve el producto encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Id Product :)",
            data: showIdProduct,
        });

    } catch(error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ACTUALIZAR PRODUCTO
// ============================

// Exporta la función para actualizar un producto
export const updateProduct = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Obtiene los nuevos datos enviados
        const dataProduct = req.body;

        // Actualiza el producto correspondiente
        await productModel.update({

            // Actualiza el nombre
            product_name: dataProduct.product_name,

            // Actualiza la descripción
            product_description: dataProduct.product_description,

            // Actualiza el precio
            product_price: dataProduct.product_price,

            // Actualiza el stock
            product_stock: dataProduct.product_stock,

            // Actualiza el estado
            product_status: dataProduct.product_status

        }, {

            // Condición para actualizar
            where: {
                product_id: id
            }
        });

        // Devuelve una respuesta indicando que fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Product :)"
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR PRODUCTO
// ============================

// Exporta la función para eliminar un producto
export const deleteProduct = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await productModel.sync();

        // Obtiene el id enviado por la URL
        const idProduct = req.params.id;

        // Elimina el producto correspondiente
        const deleteProduct = await productModel.destroy({

            // Condición para eliminar
            where: {
                product_id: idProduct,
            }
        });

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Product :)",
            data: deleteProduct,
        });

    } catch(error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};