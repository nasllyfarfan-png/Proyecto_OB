// Importa el modelo Carrito para interactuar con la tabla
// carrito de la base de datos
import carritoModel from "../models/carrito.model.js";


// ============================
// CREAR CARRITO
// ============================

// Exporta la función para crear un nuevo carrito
export const createCarrito = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataCarrito = req.body;

        // Crea un nuevo registro en la tabla carrito
        await carritoModel.create({

            // Guarda el id del usuario propietario del carrito
            id_usuario: dataCarrito.id_usuario,

            // Guarda la cantidad de productos
            cantidad: dataCarrito.cantidad,

            // Guarda la fecha en que fue agregado
            fecha_agregado: dataCarrito.fecha_agregado
        });

        // Devuelve una respuesta indicando que el carrito fue creado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Create Carrito :)"
        });

    } catch (error) {

        // Muestra el error en la consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODOS LOS CARRITOS
// ============================

export const showCarrito = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await carritoModel.sync();

        // Obtiene todos los carritos registrados
        const carrito = await carritoModel.findAll();

        // Devuelve la lista de carritos
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Carrito :)",
            data: carrito
        });

    } catch (error) {

        // Devuelve un error si falla la consulta
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR CARRITO POR ID
// ============================

export const showIdCarrito = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await carritoModel.sync();

        // Obtiene el id enviado en la URL
        const { id } = req.params;

        // Busca un carrito por su identificador
        const carrito = await carritoModel.findOne({
            where: {

                // Condición de búsqueda
                id_carrito: id
            }
        });

        // Devuelve el carrito encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Carrito :)",
            data: carrito
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ACTUALIZAR CARRITO
// ============================

export const updateCarrito = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Obtiene los nuevos datos enviados
        const dataCarrito = req.body;

        // Actualiza el carrito correspondiente
        await carritoModel.update(
            {

                // Actualiza el usuario asociado al carrito
                id_user: dataCarrito.id_usuario,

                // Actualiza la cantidad de productos
                cantidad: dataCarrito.cantidad,

                // Actualiza la fecha
                fecha_agregado: dataCarrito.fecha_agregado
            },
            {

                // Indica qué registro será actualizado
                where: {
                    id_carrito: id
                }
            }
        );

        // Devuelve un mensaje indicando que el carrito fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Carrito :)"
        });

    } catch (error) {

        // Muestra el error en la consola
        console.log(error);

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR CARRITO
// ============================

export const deleteCarrito = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Elimina el carrito correspondiente
        const carrito = await carritoModel.destroy({

            // Condición para eliminar el registro
            where: {
                id_carrito: id
            }
        });

        // Devuelve una respuesta indicando que el carrito fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Carrito :)",
            data: carrito
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};