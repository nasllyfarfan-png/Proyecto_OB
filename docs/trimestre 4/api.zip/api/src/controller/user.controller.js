// Importa la librería bcrypt para encriptar y comparar contraseñas
import bcrypt from "bcrypt";

// Importa la librería jsonwebtoken para generar y verificar tokens JWT
import jwt from "jsonwebtoken";

// Importa faker para generar datos falsos (usuarios de prueba)
import { faker } from "@faker-js/faker";

// Importa el modelo User para interactuar con la tabla de usuarios
import userModel from "../models/user.model.js";


// ============================
// CREAR USUARIO
// ============================

// Exporta la función para crear un usuario
export const createUser = async (req, res) => {
  try {

    // Genera una "sal" con 10 rondas para hacer más segura la contraseña
    const salt = await bcrypt.genSalt(10);

    // Encripta la contraseña enviada por el cliente
    const passwordHash = await bcrypt.hash(req.body.user_password, salt);

    // Crea un nuevo usuario en la base de datos
    const newUser = await userModel.create({

      // Guarda el correo o nombre del usuario
      user_user: req.body.user_user,

      // Guarda la contraseña ya encriptada
      user_password: passwordHash,

      // Guarda el estado del usuario
      userStatus_fk: req.body.userStatus_fk,

      // Guarda el rol del usuario
      role_fk: req.body.role_fk
    });

    // Responde con éxito
    return res.status(201).json({
      ok: true,
      status: 201,
      message: "User created successfully :)",
      data: newUser
    });

  } catch (error) {

    // Muestra el error en consola
    console.log(error);

    // Responde con error del servidor
    return res.status(500).json({
      ok: false,
      status: 500,
      message: "Internal server error",
      error: error.message
    });
  }
};


// ============================
// MOSTRAR TODOS LOS USUARIOS
// ============================

export const showUser = async (req, res) => {
    try {

        // Obtiene todos los usuarios de la base de datos
        const users = await userModel.findAll();

        // Retorna la lista de usuarios
        return res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Users :)",
            data: users
        });

    } catch (error) {

        // Retorna error si falla la consulta
        return res.status(500).json({
            ok: false,
            status: 500,
            message: "Something went wrong in the request",
            error: error.message
        });
    }
};


// ============================
// MOSTRAR USUARIO POR ID
// ============================

export const showUserId = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idUser = req.params.id;

        // Busca un usuario por su id
        const user = await userModel.findOne({
            where: { id_usuario: idUser }
        });

        // Si no existe devuelve error 404
        if (!user) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "User not found"
            });
        }

        // Devuelve el usuario encontrado
        return res.status(200).json({
            ok: true,
            status: 200,
            message: "Show User Id :)",
            data: user
        });

    } catch (error) {

        // Error interno del servidor
        return res.status(500).json({
            ok: false,
            status: 500,
            message: "Something went wrong in the request",
            error: error.message
        });
    }
};


// ============================
// ACTUALIZAR USUARIO
// ============================

export const updateUser = async (req, res) => {
    try {

        // Obtiene el id desde la URL
        const idUser = req.params.id;

        // Obtiene los nuevos datos enviados
        const dataUser = req.body;

        // Encripta la nueva contraseña
        const passwordHash = await bcrypt.hash(dataUser.user_password, 10);

        // Busca el usuario
        const user = await userModel.findOne({
            where: { user_id: idUser }
        });

        // Si no existe responde 404
        if (!user) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "User not found"
            });
        }

        // Actualiza la información del usuario
        await user.update({

            // Actualiza el correo
            user_user: dataUser.user_user,

            // Actualiza la contraseña encriptada
            user_password: passwordHash,

            // Actualiza el estado
            userStatus_fk: dataUser.userStatus_fk,

            // Actualiza el rol
            role_fk: dataUser.role_fk
        });

        // Devuelve respuesta exitosa
        return res.status(200).json({
            ok: true,
            status: 200,
            message: "User updated successfully :)",
            data: user
        });

    } catch (error) {

        // Error del servidor
        return res.status(500).json({
            ok: false,
            status: 500,
            message: "Something went wrong in the request",
            error: error.message
        });
    }
};


// ============================
// ELIMINAR USUARIO
// ============================

export const deleteUser = async (req, res) => {
    try {

        // Obtiene el id del usuario
        const idUser = req.params.id;

        // Busca el usuario
        const user = await userModel.findOne({
            where: { user_id: idUser }
        });

        // Si no existe devuelve 404
        if (!user) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "User not found"
            });
        }

        // Elimina el usuario de la base de datos
        await user.destroy();

        // Devuelve mensaje de éxito
        return res.status(200).json({
            ok: true,
            status: 200,
            message: "User deleted successfully :)"
        });

    } catch (error) {

        // Error interno
        return res.status(500).json({
            ok: false,
            status: 500,
            message: "Something went wrong in the request",
            error: error.message
        });
    }
};


// ============================
// CREAR USUARIO FALSO
// ============================

export const createUserfk = async (req, res) => {
    try {

        // Crea un usuario con datos aleatorios usando Faker
        const createUsers = await userModel.create({

            // Genera un correo aleatorio
            user_user: faker.internet.email(),

            // Genera una contraseña aleatoria
            user_password: faker.internet.password(),

            // Asigna estado 1
            userStatus_fk: 1,

            // Asigna rol 1
            role_fk: 1
        });

        // Devuelve el id creado
        return res.status(200).json({
            ok: true,
            status: 200,
            message: "Create Fake User :)",
            id: createUsers.user_id
        });

    } catch (error) {

        // Error del servidor
        return res.status(500).json({
            ok: false,
            status: 500,
            message: "Something went wrong in the request",
            error: error.message
        });
    }
};


// ============================
// LOGIN
// ============================

// ============================
// LOGIN
// ============================

export const loginUser = async (req, res) => {
    try {

        // Obtener correo y contraseña
        const { user_user, user_password } = req.body;

        // Validar datos
        if (!user_user || !user_password) {
            return res.status(400).json({
                ok: false,
                message: "El correo y la contraseña son obligatorios"
            });
        }

        // Buscar usuario
        const user = await userModel.findOne({
            where: {
                user_user: user_user
            }
        });

        // Usuario no encontrado
        if (!user) {
            return res.status(401).json({
                ok: false,
                message: "Correo o contraseña incorrectos"
            });
        }

        // Comparar contraseña
        const isPasswordValid = await bcrypt.compare(
            user_password,
            user.user_password
        );

        if (!isPasswordValid) {
            return res.status(401).json({
                ok: false,
                message: "Correo o contraseña incorrectos"
            });
        }

        // Verificar JWT_SECRET
        if (!process.env.JWT_SECRET) {
            console.error("ERROR: JWT_SECRET no está definido en .env");

            return res.status(500).json({
                ok: false,
                message: "JWT_SECRET no está configurado"
            });
        }

        // Crear token JWT
        const token = jwt.sign(
            {
                id: user.id_usuario,
                role: user.role_fk
            },
            process.env.JWT_SECRET,
            {
                expiresIn: "1h"
            }
        );

        // Guardar token en cookie
        res.cookie("token", token, {
    httpOnly: true,
    secure: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 1000
});
        // Respuesta del login
        return res.status(200).json({
            ok: true,
            message: "Inicio de sesión exitoso",

            // AQUÍ DEVOLVEMOS EL TOKEN
            token: token,

            user: {
                id: user.id_usuario,
                email: user.user_user,
                role: user.role_fk
            }
        });

    } catch (error) {

        console.error("ERROR LOGIN:", error);

        return res.status(500).json({
            ok: false,
            message: "Error interno del servidor",
            error: error.message
        });
    }
};


// ============================
// LOGOUT
// ============================

export const logoutUser = (req, res) => {

    // Eliminar cookie del token
    res.clearCookie("token", {
        httpOnly: true,
        secure: false,
        sameSite: "lax"
    });

    return res.status(200).json({
        ok: true,
        status: 200,
        message: "Sesión cerrada correctamente"
    });
};


// ============================
// OBJETO CONTROLADOR
// ============================

// Agrupa todas las funciones del controlador
const UserController = {
    createUser,
    showUser,
    showUserId,
    updateUser,
    deleteUser,
    createUserfk,
    loginUser,
    logoutUser
};

// Exporta el controlador para usarlo en las rutas
export default UserController;