// Importa el modelo DetalleVentas para realizar operaciones
// sobre la tabla detalle_ventas de la base de datos
import DetalleVentas from "../models/detalle_ventas.model.js";


// ============================
// CREAR DETALLE DE VENTA
// ============================

// Exporta la función para crear un nuevo detalle de venta
export const createDetalleVenta = async (req, res) => {
    try {

        // Crea un nuevo registro en la tabla detalle_ventas
        const detalleVenta = await DetalleVentas.create({

            // Guarda el id de la venta
            id_venta: req.body.id_venta,

            // Guarda el id del producto vendido
            id_producto: req.body.id_producto,

            // Guarda la talla del producto
            talla: req.body.talla,

            // Guarda la cantidad vendida
            cantidad: req.body.cantidad,

            // Guarda el color del producto
            color: req.body.color,

            // Guarda el precio por unidad
            precio_unitario: req.body.precio_unitario,

            // Guarda el subtotal de la venta
            subtotal: req.body.subtotal
        });

        // Devuelve una respuesta indicando que el detalle fue creado
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Detalle de venta creado correctamente.",
            data: detalleVenta
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODOS LOS DETALLES
// ============================

// Exporta la función para listar todos los detalles de ventas
export const showDetalleVentas = async (req, res) => {
    try {

        // Consulta todos los registros de la tabla detalle_ventas
        const detalles = await DetalleVentas.findAll();

        // Devuelve la lista de detalles encontrados
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Lista de detalles de ventas.",
            data: detalles
        });

    } catch (error) {

        // Devuelve un error si ocurre una excepción
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR DETALLE POR ID
// ============================

// Exporta la función para consultar un detalle de venta específico
export const showIdDetalleVenta = async (req, res) => {
    try {

        // Obtiene el id enviado en la URL
        const { id } = req.params;

        // Busca un detalle de venta por su identificador
        const detalle = await DetalleVentas.findOne({
            where: {

                // Condición de búsqueda
                id_detalle: id
            }
        });

        // Si el detalle no existe devuelve error 404
        if (!detalle) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Detalle de venta no encontrado."
            });
        }

        // Devuelve el detalle encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Detalle de venta encontrado.",
            data: detalle
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ACTUALIZAR DETALLE DE VENTA
// ============================

// Exporta la función para actualizar un detalle de venta
export const updateDetalleVenta = async (req, res) => {
    try {

        // Obtiene el id enviado en la URL
        const { id } = req.params;

        // Actualiza el registro correspondiente
        const [updated] = await DetalleVentas.update(

            {

                // Actualiza la venta
                id_venta: req.body.id_venta,

                // Actualiza el producto
                id_producto: req.body.id_producto,

                // Actualiza la talla
                talla: req.body.talla,

                // Actualiza la cantidad
                cantidad: req.body.cantidad,

                // Actualiza el color
                color: req.body.color,

                // Actualiza el precio unitario
                precio_unitario: req.body.precio_unitario,

                // Actualiza el subtotal
                subtotal: req.body.subtotal
            },

            {

                // Indica qué registro será actualizado
                where: {
                    id_detalle: id
                }
            }
        );

        // Si no se actualizó ningún registro devuelve error 404
        if (updated === 0) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Detalle de venta no encontrado."
            });
        }

        // Consulta nuevamente el registro actualizado
        const detalleActualizado = await DetalleVentas.findOne({
            where: {
                id_detalle: id
            }
        });

        // Devuelve el detalle actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Detalle de venta actualizado correctamente.",
            data: detalleActualizado
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR DETALLE DE VENTA
// ============================

// Exporta la función para eliminar un detalle de venta
export const deleteDetalleVenta = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Elimina el registro correspondiente
        const deleted = await DetalleVentas.destroy({

            // Condición para eliminar
            where: {
                id_detalle: id
            }
        });

        // Si no se eliminó ningún registro devuelve error 404
        if (deleted === 0) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Detalle de venta no encontrado."
            });
        }

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Detalle de venta eliminado correctamente."
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};