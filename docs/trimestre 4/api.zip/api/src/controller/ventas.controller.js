// Importa el modelo Ventas para realizar operaciones
// sobre la tabla ventas de la base de datos
import ventasModel from "../models/ventas.model.js";


// ============================
// CREAR VENTA
// ============================

// Exporta la función para crear una nueva venta
export const createVenta = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataVenta = req.body;

        // Inserta una nueva venta en la base de datos
        await ventasModel.create({

            // Guarda el usuario que realizó la compra
            id_usuario: dataVenta.id_usuario,

            // Guarda el método de pago utilizado
            id_medio_pago: dataVenta.id_medio_pago,

            // Guarda el método de envío seleccionado
            id_medio_envio: dataVenta.id_medio_envio,

            // Guarda el teléfono del cliente
            telefono: dataVenta.telefono,

            // Guarda la dirección de envío
            direccion_envio: dataVenta.direccion_envio,

            // Guarda la ciudad de entrega
            ciudad: dataVenta.ciudad,

            // Guarda la fecha de la venta
            fecha_venta: dataVenta.fecha_venta,

            // Guarda el subtotal de la compra
            subtotal: dataVenta.subtotal,

            // Guarda el costo del envío
            costo_envio: dataVenta.costo_envio,

            // Guarda el valor total de la venta
            total: dataVenta.total,

            // Guarda el estado de la venta
            estado_venta: dataVenta.estado_venta
        });

        // Devuelve una respuesta indicando que la venta fue creada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Create Venta :)"
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODAS LAS VENTAS
// ============================

// Exporta la función para consultar todas las ventas
export const showVentas = async (req, res) => {
    try {

        // Obtiene todas las ventas registradas
        const showVentas = await ventasModel.findAll();

        // Devuelve la lista de ventas
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Ventas :)",
            data: showVentas
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR VENTA POR ID
// ============================

// Exporta la función para buscar una venta por su identificador
export const showIdVenta = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idVenta = req.params.id;

        // Busca la venta correspondiente
        const showIdVenta = await ventasModel.findOne({
            where: {

                // Condición de búsqueda
                id_ventas: idVenta
            }
        });

        // Devuelve la venta encontrada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Id Venta :)",
            data: showIdVenta
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ACTUALIZAR VENTA
// ============================

// Exporta la función para actualizar una venta
export const updateVenta = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Obtiene los nuevos datos enviados
        const dataVenta = req.body;

        // Actualiza la venta correspondiente
        await ventasModel.update({

            // Actualiza el método de pago
            id_medio_pago: dataVenta.id_medio_pago,

            // Actualiza el método de envío
            id_medio_envio: dataVenta.id_medio_envio,

            // Actualiza el teléfono
            telefono: dataVenta.telefono,

            // Actualiza la dirección de envío
            direccion_envio: dataVenta.direccion_envio,

            // Actualiza la ciudad
            ciudad: dataVenta.ciudad,

            // Actualiza el subtotal
            subtotal: dataVenta.subtotal,

            // Actualiza el costo de envío
            costo_envio: dataVenta.costo_envio,

            // Actualiza el total
            total: dataVenta.total,

            // Actualiza el estado de la venta
            estado_venta: dataVenta.estado_venta

        }, {

            // Condición para actualizar
            where: {
                id_ventas: id
            }
        });

        // Devuelve una respuesta indicando que la venta fue actualizada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Venta :)"
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR VENTA
// ============================

// Exporta la función para eliminar una venta
export const deleteVenta = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idVenta = req.params.id;

        // Elimina la venta correspondiente
        const deleteVenta = await ventasModel.destroy({

            // Condición para eliminar
            where: {
                id_ventas: idVenta
            }
        });

        // Devuelve una respuesta indicando que la venta fue eliminada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Venta :)",
            data: deleteVenta
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};