// Importa el modelo CarritoItems para realizar operaciones
// sobre la tabla carrito_items en la base de datos
import carritoItemsModel from "../models/carrito_items.model.js";


// ============================
// CREAR ITEM DEL CARRITO
// ============================

// Exporta la función para crear un nuevo producto dentro del carrito
export const createCarritoItem = async (req, res) => {
    try {

        // Obtiene la información enviada por el cliente
        const dataCarritoItem = req.body;

        // Inserta un nuevo registro en la tabla carrito_items
        const createCarritoItem = await carritoItemsModel.create({

            // Guarda el id del carrito al que pertenece
            id_carrito: dataCarritoItem.id_carrito,

            // Guarda el id del producto
            id_productos: dataCarritoItem.id_productos,

            // Guarda la talla seleccionada
            talla: dataCarritoItem.talla,

            // Guarda la cantidad del producto
            cantidad: dataCarritoItem.cantidad,

            // Guarda el color del producto
            color: dataCarritoItem.color,

            // Guarda el precio por unidad
            precio_unitario: dataCarritoItem.precio_unitario,

            // Guarda el subtotal del producto
            subtotal: dataCarritoItem.subtotal
        });

        // Devuelve una respuesta indicando que el registro fue creado
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Create Carrito Item :)",

            // Devuelve el id generado
            id: createCarritoItem.id
        });

    } catch (error) {

        // Si ocurre un error devuelve estado 500
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODOS LOS ITEMS
// ============================

export const showCarritoItems = async (req, res) => {
    try {

        // Obtiene todos los registros de la tabla carrito_items
        const data = await carritoItemsModel.findAll();

        // Devuelve todos los productos encontrados
        res.status(200).json({
            message: "Carrito Items found",
            data
        });

    } catch (error) {

        // Devuelve un error si falla la consulta
        res.status(500).json({
            message: error.message,
            status: 500
        });

    }
};


// ============================
// MOSTRAR ITEM POR ID
// ============================

export const showIdCarritoItem = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const id = req.params.id;

        // Busca un único registro según el id
        const showIdCarritoItem = await carritoItemsModel.findOne({

            where: {

                // Condición de búsqueda
                id: id
            }
        });

        // Devuelve el registro encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Id Carrito Item :)",
            data: showIdCarritoItem
        });

    } catch (error) {

        // Error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });

    }
};


// ============================
// ACTUALIZAR ITEM DEL CARRITO
// ============================

export const updateCarritoItem = async (req, res) => {
    try {

        // Obtiene los nuevos datos enviados
        const dataCarritoItem = req.body;

        // Obtiene el id desde la URL
        const id = req.params.id;

        // Actualiza el registro correspondiente
        const updateCarritoItem = await carritoItemsModel.update({

            // Actualiza el carrito
            id_carrito: dataCarritoItem.id_carrito,

            // Actualiza el producto
            id_productos: dataCarritoItem.id_productos,

            // Actualiza la talla
            talla: dataCarritoItem.talla,

            // Actualiza la cantidad
            cantidad: dataCarritoItem.cantidad,

            // Actualiza el color
            color: dataCarritoItem.color,

            // Actualiza el precio unitario
            precio_unitario: dataCarritoItem.precio_unitario,

            // Actualiza el subtotal
            subtotal: dataCarritoItem.subtotal

        }, {

            // Indica qué registro debe actualizarse
            where: {
                id: id
            }
        });

        // Devuelve una respuesta indicando que el registro fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Carrito Item :)",
            data: updateCarritoItem
        });

    } catch (error) {

        // Devuelve un error si ocurre alguna excepción
        return res.status(500).json({
            message: error.message,
            status: 500
        });

    }
};


// ============================
// ELIMINAR ITEM DEL CARRITO
// ============================

export const deleteCarritoItem = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const id = req.params.id;

        // Elimina el registro correspondiente
        const deleteCarritoItem = await carritoItemsModel.destroy({

            where: {

                // Condición para eliminar
                id: id
            }
        });

        // Devuelve una respuesta indicando que el registro fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Carrito Item :)",
            data: deleteCarritoItem
        });

    } catch (error) {

        // Si ocurre un error devuelve estado 500
        return res.status(500).json({
            message: error.message,
            status: 500
        });

    }
};