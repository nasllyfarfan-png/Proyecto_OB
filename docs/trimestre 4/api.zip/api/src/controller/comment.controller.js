// Importa el modelo Comment para realizar operaciones
// sobre la tabla de comentarios en la base de datos
import commentModel from "../models/comment.model.js";


// ============================
// CREAR COMENTARIO
// ============================

// Exporta la función para crear un nuevo comentario
export const createComment = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataComment = req.body;

        // Crea un nuevo comentario en la base de datos
        const comment = await commentModel.create({

            // Guarda el id del usuario que realizó el comentario
            id_usuarios: dataComment.id_usuarios,

            // Guarda el id del producto comentado
            id_productos: dataComment.id_productos,

            // Guarda la calificación del producto
            calificacion: dataComment.calificacion,

            // Guarda el texto del comentario
            comment: dataComment.comment,

            // Guarda la fecha del comentario
            fecha: dataComment.fecha,

            // Guarda el estado del comentario
            estado: dataComment.estado
        });

        // Devuelve una respuesta indicando que el comentario fue creado
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Comment created :)",

            // Devuelve el id del comentario creado
            id: comment.id_comment
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// MOSTRAR TODOS LOS COMENTARIOS
// ============================

export const showComment = async (req, res) => {
    try {

        // Obtiene todos los comentarios registrados
        const data = await commentModel.findAll();

        // Devuelve la lista de comentarios
        res.status(200).json({
            message: "Comments found",
            data
        });

    } catch (error) {

        // Devuelve un error si ocurre una excepción
        res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });

    }
};


// ============================
// MOSTRAR COMENTARIO POR ID
// ============================

export const showIdComment = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Muestra el id recibido en la consola (para depuración)
        console.log("ID recibido:", id);

        // Busca el comentario utilizando su llave primaria
        const comment = await commentModel.findByPk(id);

        // Muestra el comentario encontrado en la consola
        console.log("Comment encontrado:", comment);

        // Si el comentario no existe devuelve error 404
        if (!comment) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Comment not found"
            });
        }

        // Devuelve el comentario encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            data: comment
        });

    } catch (error) {

        // Muestra el error en la consola
        console.log(error);

        // Devuelve un error interno del servidor
        res.status(500).json({
            message: "Something went wrong in the request",
            error: error.message
        });
    }
};


// ============================
// ACTUALIZAR COMENTARIO
// ============================

export const updateComment = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idComment = req.params.id;

        // Obtiene los nuevos datos enviados por el cliente
        const dataComment = req.body;

        // Actualiza el comentario correspondiente
        const comment = await commentModel.update({

            // Actualiza el usuario
            id_usuarios: dataComment.id_usuarios,

            // Actualiza el producto
            id_productos: dataComment.id_productos,

            // Actualiza la calificación
            calificacion: dataComment.calificacion,

            // Actualiza el texto del comentario
            comment: dataComment.comment,

            // Actualiza la fecha
            fecha: dataComment.fecha,

            // Actualiza el estado
            estado: dataComment.estado

        }, {

            // Indica qué comentario debe actualizarse
            where: {
                id_comment: idComment
            }
        });

        // Devuelve una respuesta indicando que el comentario fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Comment :)",
            data: comment
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });

    }
};


// ============================
// ELIMINAR COMENTARIO
// ============================

export const deleteComment = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idComment = req.params.id;

        // Elimina el comentario correspondiente
        const comment = await commentModel.destroy({

            // Condición para eliminar el registro
            where: {
                id_comment: idComment
            }
        });

        // Devuelve una respuesta indicando que el comentario fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Comment :)",
            data: comment
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });

    }
};