// Importa el modelo MetodoPago para realizar operaciones
// sobre la tabla metodo_pago de la base de datos
import metodosPagoModel from "../models/metodo_pago.model.js";


// ============================
// CREAR MÉTODO DE PAGO
// ============================

// Exporta la función para crear un nuevo método de pago
export const createMetodoPago = async (req, res) => {
    try {

        // Obtiene los datos enviados desde el cliente
        const dataMetodoPago = req.body;

        // Crea un nuevo método de pago en la base de datos
        const createMedioPago = await metodosPagoModel.create({

            // Guarda el nombre del método de pago
            nombre_metodo: dataMetodoPago.nombre_metodo,

            // Guarda el tipo de método (efectivo, tarjeta, transferencia, etc.)
            tipo: dataMetodoPago.tipo,

            // Guarda la descripción del método
            descripcion: dataMetodoPago.descripcion,

            // Guarda el estado del método (activo o inactivo)
            activo: dataMetodoPago.activo
        });

        // Devuelve una respuesta indicando que el método fue creado
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Create Metodo Pago :)",

            // Devuelve el identificador generado
            id: createMedioPago.id_medio_pago
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODOS LOS MÉTODOS DE PAGO
// ============================

// Exporta la función para consultar todos los métodos de pago
export const showMetodosPago = async (req, res) => {
    try {

        // Obtiene todos los métodos registrados
        const data = await metodosPagoModel.findAll();

        // Devuelve la lista de métodos de pago
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Metodos de pago encontrados",
            data
        });

    } catch (error) {

        // Devuelve un error interno
        res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR MÉTODO DE PAGO POR ID
// ============================

// Exporta la función para buscar un método de pago específico
export const showIdMetodoPago = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idMetodoPago = req.params.id;

        // Busca el método de pago correspondiente
        const metodoPago = await metodosPagoModel.findOne({
            where: {

                // Condición de búsqueda
                id_medio_pago: idMetodoPago
            }
        });

        // Si no existe devuelve error 404
        if (!metodoPago) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Metodo de pago no encontrado"
            });
        }

        // Devuelve el método encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Metodo de pago encontrado",
            data: metodoPago
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ACTUALIZAR MÉTODO DE PAGO
// ============================

// Exporta la función para actualizar un método de pago
export const updateMetodoPago = async (req, res) => {
    try {

        // Obtiene los nuevos datos enviados
        const dataMetodoPago = req.body;

        // Obtiene el id enviado por la URL
        const idMetodoPago = req.params.id;

        // Verifica si el método existe
        const existe = await metodosPagoModel.findOne({
            where: {
                id_medio_pago: idMetodoPago
            }
        });

        // Si no existe devuelve error 404
        if (!existe) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Metodo de pago no encontrado"
            });
        }

        // Actualiza el método de pago
        await metodosPagoModel.update({

            // Actualiza el nombre
            nombre_metodo: dataMetodoPago.nombre_metodo,

            // Actualiza el tipo
            tipo: dataMetodoPago.tipo,

            // Actualiza la descripción
            descripcion: dataMetodoPago.descripcion,

            // Actualiza el estado
            activo: dataMetodoPago.activo

        }, {

            // Condición para actualizar
            where: {
                id_medio_pago: idMetodoPago
            }
        });

        // Devuelve una respuesta indicando que fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Metodo de pago actualizado exitosamente"
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR MÉTODO DE PAGO
// ============================

// Exporta la función para eliminar un método de pago
export const deleteMetodoPago = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idMetodoPago = req.params.id;

        // Verifica si el método existe
        const existe = await metodosPagoModel.findOne({
            where: {
                id_medio_pago: idMetodoPago
            }
        });

        // Si no existe devuelve error 404
        if (!existe) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "Metodo de pago no encontrado"
            });
        }

        // Elimina el método de pago
        await metodosPagoModel.destroy({

            // Condición para eliminar
            where: {
                id_medio_pago: idMetodoPago
            }
        });

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Metodo de pago eliminado exitosamente"
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};