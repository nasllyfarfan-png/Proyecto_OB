// Importa el modelo Notificaciones para realizar operaciones
// sobre la tabla notificaciones de la base de datos
import notificaciones from "../models/notificaciones.model.js";


// ============================
// CREAR NOTIFICACIÓN
// ============================

// Exporta la función para crear una nueva notificación
export const createNotificaciones = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataNotification = req.body;

        // Crea una nueva notificación en la base de datos
        const newNotification = await notificaciones.create({

            // Guarda el id del usuario al que pertenece la notificación
            id_usuario: dataNotification.id_usuario,

            // Guarda el mensaje de la notificación
            mensaje: dataNotification.mensaje,

            // Guarda el tipo de notificación
            tipo: dataNotification.tipo,

            // Guarda la fecha de la notificación
            fecha_notificaciones: dataNotification.fecha_notificaciones,

            // Guarda el estado de la notificación
            estado_notificaciones: dataNotification.estado_notificaciones,
        });

        // Devuelve una respuesta indicando que la notificación fue creada
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Create Notification :)",

            // Devuelve el id generado
            id: newNotification.id_notificaciones,
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// MOSTRAR TODAS LAS NOTIFICACIONES
// ============================

// Exporta la función para consultar todas las notificaciones
export const showNotificaciones = async (req, res) => {
    try {

        // Obtiene todas las notificaciones registradas
        const data = await notificaciones.findAll();

        // Devuelve la lista de notificaciones
        res.status(200).json({
            message: "Notifications found",
            data
        });

    } catch (error) {

        // Devuelve un error interno
        res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// MOSTRAR NOTIFICACIÓN POR ID
// ============================

// Exporta la función para buscar una notificación por su identificador
export const showIdNotificaciones = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await notificaciones.sync();

        // Obtiene el id enviado en la URL
        const idNotification = req.params.id;

        // Busca la notificación correspondiente
        const notification = await notificaciones.findOne({
            where: {

                // Condición de búsqueda
                id_notificaciones: idNotification,
            }
        });

        // Devuelve la notificación encontrada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Id Notification :)",
            data: notification,
        });

    } catch(error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// ACTUALIZAR NOTIFICACIÓN
// ============================

// Exporta la función para actualizar una notificación
export const updateNotificaciones = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await notificaciones.sync();

        // Obtiene los nuevos datos enviados
        const dataNotification = req.body;

        // Obtiene el id enviado por la URL
        const idNotification = req.params.id;

        // Actualiza la notificación correspondiente
        const updatedNotification = await notificaciones.update({

            // Actualiza el usuario
            id_usuario: dataNotification.id_usuario,

            // Actualiza el mensaje
            mensaje: dataNotification.mensaje,

            // Actualiza el tipo
            tipo: dataNotification.tipo,

            // Actualiza la fecha
            fecha_notificaciones: dataNotification.fecha_notificaciones,

            // Actualiza el estado
            estado_notificaciones: dataNotification.estado_notificaciones,

            // Actualiza la llave foránea del usuario
            Usuarios_id_usuarios: dataNotification.Usuarios_id_usuarios

        }, {

            // Condición para actualizar
            where: {
                id_notificaciones: idNotification,
            }
        });

        // Devuelve una respuesta indicando que fue actualizada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Notification :)",
            data: updatedNotification,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// ELIMINAR NOTIFICACIÓN
// ============================

// Exporta la función para eliminar una notificación
export const deleteNotificaciones = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await notificaciones.sync();

        // Obtiene el id enviado por la URL
        const idNotification = req.params.id;

        // Elimina la notificación correspondiente
        const deletedNotification = await notificaciones.destroy({

            // Condición para eliminar
            where: {
                id_notificaciones: idNotification,
            }
        });

        // Devuelve una respuesta indicando que fue eliminada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Notification :)",
            data: deletedNotification,
        });

    } catch(error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};