// Importa el modelo Category para realizar operaciones
// sobre la tabla de categorías de la base de datos
import categoryModel from "../models/category.model.js";


// ============================
// CREAR CATEGORÍA
// ============================

// Exporta la función para crear una nueva categoría
export const createCategory = async (req, res) => {
    try {

        // Obtiene los datos enviados desde el cliente
        const dataCategory = req.body;

        // Crea una nueva categoría en la base de datos
        await categoryModel.create({

            // Guarda el nombre de la categoría
            category_name: dataCategory.category_name,

            // Guarda la descripción de la categoría
            category_description: dataCategory.category_description,

            // Guarda el estado de la categoría
            category_status: dataCategory.category_status,

            // Guarda la imagen de la categoría
            category_image: dataCategory.category_image,

            // Guarda el código de la categoría
            category_code: dataCategory.category_code,

            // Guarda el usuario que creó la categoría
            category_created_by: dataCategory.category_created_by

        });

        // Devuelve una respuesta indicando que la categoría fue creada
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Create Category :)",

            // Devuelve el id de la categoría creada
            id: createCategory.category_id,
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// MOSTRAR TODAS LAS CATEGORÍAS
// ============================

export const showCategory = async (req, res) => {
    try {

        // Obtiene todas las categorías registradas
        const data = await categoryModel.findAll();

        // Devuelve la lista de categorías
        res.status(200).json({
            message: "Categories found",
            data
        });

    } catch (error) {

        // Devuelve un error si falla la consulta
        res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });

    }
};


// ============================
// MOSTRAR CATEGORÍA POR ID
// ============================

export const showIdCategory = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await categoryModel.sync();

        // Obtiene el id enviado por la URL
        const idCategory = req.params.id;

        // Busca una categoría por su id
        const showIdCategory = await categoryModel.findOne({
            where: {

                // Condición de búsqueda
                category_id: idCategory,
            }
        });

        // Devuelve la categoría encontrada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Id Category :)",
            data: showIdCategory,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ACTUALIZAR CATEGORÍA
// ============================

export const updateCategory = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await categoryModel.sync();

        // Obtiene los nuevos datos enviados
        const dataCategory = req.body;

        // Obtiene el id enviado por la URL
        const idCategory = req.params.id;

        // Actualiza la categoría correspondiente
        const updateCategory = await categoryModel.update({

            // Actualiza el nombre
            category_name: dataCategory.category_name,

            // Actualiza la descripción
            category_description: dataCategory.category_description,

            // Actualiza el estado
            category_status: dataCategory.category_status,

            // Actualiza la imagen
            category_image: dataCategory.category_image,

            // Actualiza el código
            category_code: dataCategory.category_code,

            // Actualiza el creador de la categoría
            category_created_by: dataCategory.category_created_by,

            // Actualiza la llave foránea del producto
            product_fk: dataCategory.product_fk

        }, {

            // Indica qué categoría se actualizará
            where: {
                category_id: idCategory,
            }
        });

        // Devuelve una respuesta indicando que fue actualizada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Category :)",
            data: updateCategory,
        });

    } catch(error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ELIMINAR CATEGORÍA
// ============================

export const deleteCategory = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await categoryModel.sync();

        // Obtiene el id enviado por la URL
        const idCategory = req.params.id;

        // Elimina la categoría correspondiente
        const deleteCategory = await categoryModel.destroy({

            // Condición para eliminar
            where: {
                category_id: idCategory,
            }
        });

        // Devuelve una respuesta indicando que fue eliminada
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Category :)",
            data: deleteCategory,
        });

    } catch(error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });

    }
};