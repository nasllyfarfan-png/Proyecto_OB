// Importa el modelo UserStatus para realizar operaciones
// sobre la tabla de estados de usuario de la base de datos
import userStatusModel from "../models/userStatus.model.js";


// ============================
// CREAR ESTADO DE USUARIO
// ============================

// Exporta la función para crear un nuevo estado de usuario
export const createUserStatus = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await userStatusModel.sync();

        // Obtiene los datos enviados por el cliente
        const dataUserStatus = req.body;

        // Inserta un nuevo estado de usuario
        const createUserStatus = await userStatusModel.create({

            // Guarda el nombre del estado
            userStatus_name: dataUserStatus.userStatus_name,

            // Guarda la descripción del estado
            userStatus_description: dataUserStatus.userStatus_description,
        });

        // Devuelve una respuesta indicando que fue creado
        res.status(201).json({
            ok: true,
            status: 201,
            message: "Create User Status :)",

            // Devuelve el id generado
            id: createUserStatus.userStatus_id,
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// MOSTRAR TODOS LOS ESTADOS
// ============================

// Exporta la función para consultar todos los estados de usuario
export const showUserStatus = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await userStatusModel.sync();

        // Obtiene todos los estados registrados
        const users = await userStatusModel.findAll();

        // Devuelve la lista de estados
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show User Status :)",
            body: users,
        });

    } catch(error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// MOSTRAR ESTADO POR ID
// ============================

// Exporta la función para buscar un estado de usuario por su identificador
export const showIdUserStatus = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idStatus = req.params.id;

        // Busca el estado correspondiente
        const user = await userStatusModel.findOne({
            where: {

                // Condición de búsqueda
                userStatus_id: idStatus,
            },
        });

        // Devuelve el estado encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show User Status Id :)",
            body: user,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ACTUALIZAR ESTADO DE USUARIO
// ============================

// Exporta la función para actualizar un estado de usuario
export const updateUserStatus = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await userStatusModel.sync();

        // Obtiene los datos enviados por el cliente
        const dataUserStatus = req.body;

        // Obtiene el id enviado por la URL
        const idStatus = req.params.id;

        // Actualiza el estado correspondiente
        const updateUser = await userStatusModel.update({

            // Actualiza el nombre del estado
            userStatus_name: dataUserStatus.userStatus_name,

            // Actualiza la descripción
            userStatus_description: dataUserStatus.userStatus_description,

        }, {

            // Condición para actualizar
            where: {
                userStatus_id: idStatus,
            }
        });

        // Devuelve una respuesta indicando que fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update User Status :)",
            body: updateUser,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ELIMINAR ESTADO DE USUARIO
// ============================

// Exporta la función para eliminar un estado de usuario
export const deleteUserStatus = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await userStatusModel.sync();

        // Obtiene el id enviado por la URL
        const idStatus = req.params.id;

        // Elimina el estado correspondiente
        const deleteUser = await userStatusModel.destroy({

            // Condición para eliminar
            where: {
                userStatus_id: idStatus,
            }
        });

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete User Status :)",
            body: deleteUser,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};