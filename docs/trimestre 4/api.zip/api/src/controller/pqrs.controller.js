// Importa el modelo PQRS para realizar operaciones
// sobre la tabla pqrs de la base de datos
import pqrsModel from "../models/pqrs.model.js";


// ============================
// CREAR PQRS
// ============================

// Exporta la función para crear una nueva solicitud PQRS
export const createPqrs = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataPqrs = req.body;

        // Crea un nuevo registro en la base de datos
        await pqrsModel.create({

            // Guarda el id de la venta asociada.
            // Si no se envía, almacena null.
            id_venta: dataPqrs.id_venta || null,

            // Guarda el id del usuario
            id_usuario: dataPqrs.id_usuario,

            // Guarda el nombre del usuario
            nombre: dataPqrs.nombre,

            // Guarda el apellido del usuario
            apellido: dataPqrs.apellido,

            // Guarda el correo electrónico
            correo: dataPqrs.correo,

            // Guarda el teléfono
            telefono: dataPqrs.telefono,

            // Guarda el tipo de PQRS
            tipo_pqrs: dataPqrs.tipo_pqrs,

            // Guarda el mensaje enviado
            mensaje_pqrs: dataPqrs.mensaje_pqrs,

            // Guarda la respuesta si existe.
            // Si no existe, almacena null.
            respuesta_pqrs: dataPqrs.respuesta_pqrs || null,

            // Guarda la fecha de creación
            fecha_pqrs: dataPqrs.fecha_pqrs,

            // Guarda la fecha de respuesta.
            // Si aún no existe, almacena null.
            fecha_respuesta: dataPqrs.fecha_respuesta || null,

            // Guarda el estado de la solicitud
            estado_pqrs: dataPqrs.estado_pqrs
        });

        // Devuelve una respuesta indicando que fue creado correctamente
        res.status(201).json({
            ok: true,
            status: 201,
            message: "PQRS creado exitosamente"
        });

    } catch (error) {

        // Muestra el error en consola
        console.log(error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR TODOS LOS PQRS
// ============================

// Exporta la función para consultar todas las solicitudes
export const showPqrs = async (req, res) => {
    try {

        // Obtiene todos los registros de la tabla PQRS
        const pqrs = await pqrsModel.findAll();

        // Devuelve la lista de PQRS
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Lista de PQRS",
            data: pqrs
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// MOSTRAR PQRS POR ID
// ============================

// Exporta la función para buscar un PQRS por su identificador
export const showIdPqrs = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idPqrs = req.params.id;

        // Busca el PQRS correspondiente
        const pqrs = await pqrsModel.findOne({
            where: {

                // Condición de búsqueda
                id_pqrs: idPqrs
            }
        });

        // Si no existe devuelve error 404
        if (!pqrs) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "PQRS no encontrado"
            });
        }

        // Devuelve el registro encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "PQRS encontrado",
            data: pqrs
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ACTUALIZAR PQRS
// ============================

// Exporta la función para actualizar un PQRS
export const updatePqrs = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const { id } = req.params;

        // Obtiene los nuevos datos enviados
        const dataPqrs = req.body;

        // Verifica si el PQRS existe
        const pqrsExiste = await pqrsModel.findOne({
            where: {
                id_pqrs: id
            }
        });

        // Si no existe devuelve error 404
        if (!pqrsExiste) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "PQRS no encontrado"
            });
        }

        // Actualiza el registro
        await pqrsModel.update({

            // Actualiza el nombre
            nombre: dataPqrs.nombre,

            // Actualiza el apellido
            apellido: dataPqrs.apellido,

            // Actualiza el correo
            correo: dataPqrs.correo,

            // Actualiza el teléfono
            telefono: dataPqrs.telefono,

            // Actualiza el tipo de PQRS
            tipo_pqrs: dataPqrs.tipo_pqrs,

            // Actualiza el mensaje
            mensaje_pqrs: dataPqrs.mensaje_pqrs,

            // Actualiza la respuesta
            respuesta_pqrs: dataPqrs.respuesta_pqrs || null,

            // Actualiza la fecha del PQRS
            fecha_pqrs: dataPqrs.fecha_pqrs,

            // Actualiza la fecha de respuesta
            fecha_respuesta: dataPqrs.fecha_respuesta || null,

            // Actualiza el estado
            estado_pqrs: dataPqrs.estado_pqrs

        }, {

            // Condición para actualizar
            where: {
                id_pqrs: id
            }
        });

        // Devuelve una respuesta indicando que fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "PQRS actualizado exitosamente"
        });

    } catch (error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};


// ============================
// ELIMINAR PQRS
// ============================

// Exporta la función para eliminar un PQRS
export const deletePqrs = async (req, res) => {
    try {

        // Obtiene el id enviado por la URL
        const idPqrs = req.params.id;

        // Verifica si el registro existe
        const pqrsExiste = await pqrsModel.findOne({
            where: {
                id_pqrs: idPqrs
            }
        });

        // Si no existe devuelve error 404
        if (!pqrsExiste) {
            return res.status(404).json({
                ok: false,
                status: 404,
                message: "PQRS no encontrado"
            });
        }

        // Elimina el registro
        await pqrsModel.destroy({

            // Condición para eliminar
            where: {
                id_pqrs: idPqrs
            }
        });

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "PQRS eliminado exitosamente"
        });

    } catch (error) {

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: error.message,
            status: 500
        });
    }
};