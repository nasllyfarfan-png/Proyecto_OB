// Importa el modelo Role para realizar operaciones
// sobre la tabla roles de la base de datos
import roleModel from "../models/role.model.js";

// Importa Faker para generar datos ficticios.
// En este controlador no se utiliza.
import { faker } from "@faker-js/faker";


// ============================
// CREAR ROL
// ============================

// Exporta la función para crear un nuevo rol
export const createRole = async (req, res) => {
    try {

        // Obtiene los datos enviados por el cliente
        const dataRole = req.body;

        // Inserta un nuevo rol en la base de datos
        const newRole = await roleModel.create({

            // Guarda el nombre del rol
            role_name: dataRole.role_name,

            // Guarda la descripción del rol
            role_description: dataRole.role_description,
        });

        // Devuelve una respuesta indicando que el rol fue creado
        return res.status(201).json({
            ok: true,
            status: 201,
            message: "Create Role :)",

            // Devuelve el id generado
            id: newRole.role_id,
        });

    } catch (error) {

        // Muestra el error en consola
        console.error("ERROR CREATE ROLE:", error);

        // Devuelve un error interno del servidor
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
            error: error.message
        });
    }
};


// ============================
// MOSTRAR TODOS LOS ROLES
// ============================

// Exporta la función para consultar todos los roles
export const showRole = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await roleModel.sync();

        // Obtiene todos los roles registrados
        const showRoles = await roleModel.findAll();

        // Devuelve la lista de roles
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Role :)",
            data: showRoles,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// MOSTRAR ROL POR ID
// ============================

// Exporta la función para buscar un rol por su identificador
export const showIdRole = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await roleModel.sync();

        // Obtiene el id enviado por la URL
        const idRole = req.params.id;

        // Busca el rol correspondiente
        const showIdRole = await roleModel.findOne({
            where: {

                // Condición de búsqueda
                role_id: idRole,
            }
        });

        // Devuelve el rol encontrado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Show Id Role :)",
            data: showIdRole,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ACTUALIZAR ROL
// ============================

// Exporta la función para actualizar un rol
export const updateRole = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await roleModel.sync();

        // Obtiene los datos enviados por el cliente
        const dataRole = req.body;

        // Obtiene el id enviado por la URL
        const idRole = req.params.id;

        // Actualiza el rol correspondiente
        const updateRole = await roleModel.update({

            // Actualiza el nombre del rol
            role_name: dataRole.role_name,

            // Actualiza la descripción del rol
            role_description: dataRole.role_description,

        }, {

            // Condición para actualizar
            where: {
                role_id: idRole,
            }
        });

        // Devuelve una respuesta indicando que fue actualizado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Update Role :)",
            data: updateRole,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};


// ============================
// ELIMINAR ROL
// ============================

// Exporta la función para eliminar un rol
export const deleteRole = async (req, res) => {
    try {

        // Sincroniza el modelo con la base de datos
        await roleModel.sync();

        // Obtiene el id enviado por la URL
        const idRole = req.params.id;

        // Elimina el rol correspondiente
        const deleteRole = await roleModel.destroy({

            // Condición para eliminar
            where: {
                role_id: idRole,
            }
        });

        // Devuelve una respuesta indicando que fue eliminado
        res.status(200).json({
            ok: true,
            status: 200,
            message: "Delete Role :)",
            data: deleteRole,
        });

    } catch(error) {

        // Devuelve un error interno
        return res.status(500).json({
            message: "Something went wrong in the request",
            status: 500,
        });
    }
};