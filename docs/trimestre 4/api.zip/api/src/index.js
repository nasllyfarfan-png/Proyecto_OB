// Importa la configuración principal de la aplicación Express.
// Aquí se encuentran registradas las rutas, middlewares y demás configuraciones.
import app from "./app/app.js";

// Importa dotenv para cargar las variables de entorno
// almacenadas en el archivo .env.
import dotenv from "dotenv";

// Importa la función que inicializa todos los modelos de Sequelize
// y establece las relaciones entre las tablas de la base de datos.
import { modelApp } from "./config/models.app.js";

// Carga las variables de entorno desde el archivo .env.
// La ruta indica que el archivo se encuentra un nivel por encima
// del directorio actual.
dotenv.config({ path: "../.env" });

// Inicializa los modelos de la aplicación.
// El parámetro true sincroniza los modelos con la base de datos.
modelApp(true);

// Obtiene el puerto desde las variables de entorno.
// Si no existe la variable SERVER_PORT, utilizará el puerto 3001.
const port = process.env.SERVER_PORT || 3001;

// Inicia el servidor Express en el puerto configurado.
app.listen(port, () => {
    console.log(`Connected Server ....${port}`);
});